package de.tactics.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TacticalDark = darkColorScheme(
    primary = Color(0xFF66BB6A),
    onPrimary = Color(0xFF07210C),
    secondary = Color(0xFFFFCA28),
    background = Color(0xFF0E1A13),
    onBackground = Color(0xFFE6F0E8),
    surface = Color(0xFF15241B),
    onSurface = Color(0xFFE6F0E8),
    surfaceVariant = Color(0xFF1F3327),
    onSurfaceVariant = Color(0xFFB9CBBE)
)

@Composable
fun TacticsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = TacticalDark, content = content)
}
