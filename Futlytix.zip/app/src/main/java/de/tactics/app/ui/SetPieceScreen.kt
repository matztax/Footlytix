@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.tactics.app.MainViewModel
import de.tactics.app.data.Player
import de.tactics.app.data.RoleAssignment
import de.tactics.app.data.SetPiece
import de.tactics.app.data.decodeRoles
import de.tactics.app.data.encodeRoles

private val TYPES = listOf("Ecke", "Freistoß", "Einwurf", "Elfmeter", "Anstoß")
private val DEFAULT_ROLES = listOf("Schütze", "Zielspieler", "Blocker", "Sperrspieler", "Absicherung", "Läufer")

@Composable
fun SetPieceScreen(vm: MainViewModel) {
    val sets by vm.setPieces.collectAsStateWithLifecycle()
    val players by vm.players.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<SetPiece?>(null) }
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        if (sets.isEmpty()) {
            Text(
                "Noch keine Standards.\nMit + einen Standard anlegen und Rollen zuweisen.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
            items(sets, key = { it.id }) { s ->
                val roles = decodeRoles(s.rolesJson).filter { it.player.isNotBlank() }
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clickable { editing = s }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.name, style = MaterialTheme.typography.titleMedium)
                                Text(s.type, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { vm.deleteSetPiece(s) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Löschen")
                            }
                        }
                        roles.forEach { Text("${it.role}: ${it.player}") }
                        if (s.notes.isNotBlank()) Text(s.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { creating = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Standard hinzufügen") }
    }

    if (creating || editing != null) {
        SetPieceDialog(
            initial = editing,
            players = players,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.saveSetPiece(it); creating = false; editing = null }
        )
    }
}

@Composable
private fun SetPieceDialog(
    initial: SetPiece?,
    players: List<Player>,
    onDismiss: () -> Unit,
    onSave: (SetPiece) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: TYPES[0]) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    val roles = remember {
        mutableStateListOf<RoleAssignment>().apply {
            addAll(
                if (initial != null && decodeRoles(initial.rolesJson).isNotEmpty()) decodeRoles(initial.rolesJson)
                else DEFAULT_ROLES.map { RoleAssignment(it, "") }
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Neuer Standard" else "Standard bearbeiten") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name (z. B. Ecke links kurz)") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TYPES.forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                    }
                }
                roles.forEachIndexed { i, r ->
                    RoleRow(r.role, r.player, players) { roles[i] = r.copy(player = it) }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("Notizen / Laufwege") }, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    val base = initial ?: SetPiece(name = "", type = type, rolesJson = "")
                    onSave(base.copy(name = name.trim(), type = type, rolesJson = encodeRoles(roles.toList()), notes = notes.trim()))
                }
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
private fun RoleRow(role: String, selected: String, players: List<Player>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(role, Modifier.weight(1f))
        Box {
            OutlinedButton(onClick = { open = true }) { Text(selected.ifBlank { "wählen" }) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("– niemand –") }, onClick = { onSelect(""); open = false })
                players.forEach { p ->
                    DropdownMenuItem(
                        text = { Text("${p.number} ${p.name}") },
                        onClick = { onSelect(p.name); open = false }
                    )
                }
            }
        }
    }
}
