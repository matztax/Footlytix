package de.tactics.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

// ---------------------------------------------------------------- Kader
@Serializable
@Entity(tableName = "players")
data class Player(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val number: Int = 0,
    val position: String = "",
    // Trainer-Profil
    val strengths: String = "",
    val weaknesses: String = "",
    val goals: String = "",
    val notes: String = "",
    // Bewertungen 0 = nicht bewertet, 1..5 Sterne
    val ratingTechnik: Int = 0,
    val ratingTaktik: Int = 0,
    val ratingAthletik: Int = 0,
    val ratingMental: Int = 0
) {
    fun averageRating(): Float? {
        val r = listOf(ratingTechnik, ratingTaktik, ratingAthletik, ratingMental).filter { it > 0 }
        return if (r.isEmpty()) null else r.average().toFloat()
    }
}

// ---------------------------------------------------------------- Taktik
/** Spielfigur auf dem Taktikfeld. x/y sind normiert (0..1). playerId = -1: kein Spieler zugewiesen. */
@Serializable
data class Token(
    val label: String,
    val x: Float,
    val y: Float,
    val opponent: Boolean = false,
    val playerId: Long = -1L
)

@Serializable
data class Phase(val name: String, val tokens: List<Token>)

@Serializable
@Entity(tableName = "formations")
data class Formation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phasesJson: String
)

@Serializable
data class RoleAssignment(val role: String, val player: String)

@Serializable
@Entity(tableName = "set_pieces")
data class SetPiece(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val rolesJson: String,
    val notes: String = ""
)

// ---------------------------------------------------------------- Video
/** Ein Strich der Zeichnung; points = x1,y1,x2,y2,... (normiert 0..1). */
@Serializable
data class Scribble(val points: List<Float>)

@Serializable
@Entity(tableName = "video_annotations")
data class VideoAnnotation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoUri: String,
    val timestampMs: Long,
    val scribblesJson: String,
    val note: String = ""
)

/** Ein Video in der Bibliothek (nur Verweis auf die Datei + frei wählbarer Name). */
@Serializable
@Entity(tableName = "video_items")
data class VideoItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val uri: String,
    val createdAt: Long = System.currentTimeMillis()
)

// ---------------------------------------------------------------- Briefing
@Serializable
@Entity(tableName = "briefings")
data class Briefing(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

// ---------------------------------------------------------------- Training
/** Element im Übungsaufbau (Material, Spieler, ...). x/y normiert (0..1). */
@Serializable
data class ExItem(
    val type: String,
    val x: Float,
    val y: Float,
    val label: String = "",
    val rotated: Boolean = false
)

data class ItemType(val key: String, val label: String, val isMaterial: Boolean)

val ITEM_TYPES = listOf(
    ItemType("cone", "Hütchen", true),
    ItemType("pole", "Stange", true),
    ItemType("wall", "Mauer", true),
    ItemType("ladder", "Koordinationsleiter", true),
    ItemType("hurdle", "Hürde", true),
    ItemType("goal", "Tor", true),
    ItemType("minigoal", "Minitor", true),
    ItemType("ball", "Ball", true),
    ItemType("player", "Spieler", false),
    ItemType("gk", "Torwart", false),
    ItemType("opp", "Gegner", false)
)

val EXERCISE_CATEGORIES = listOf(
    "Aufwärmen", "Technik", "Passspiel", "Taktik", "Spielform",
    "Abschluss", "Athletik", "Torwart", "Auslaufen"
)

@Serializable
@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "Technik",
    val durationMin: Int = 10,
    val playersCount: Int = 0,
    val description: String = "",
    val extraMaterial: String = "",
    val itemsJson: String = "[]",
    val scribblesJson: String = "[]"
)

@Serializable
data class SessionEntry(val exerciseId: Long, val minutes: Int)

@Serializable
@Entity(tableName = "training_sessions")
data class TrainingSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val date: String = "",
    val goal: String = "",
    val notes: String = "",
    val entriesJson: String = "[]"
)

// ---------------------------------------------------------------- Backup
@Serializable
data class BackupBundle(
    val version: Int = 3,
    val players: List<Player> = emptyList(),
    val formations: List<Formation> = emptyList(),
    val setPieces: List<SetPiece> = emptyList(),
    val annotations: List<VideoAnnotation> = emptyList(),
    val briefings: List<Briefing> = emptyList(),
    val exercises: List<Exercise> = emptyList(),
    val sessions: List<TrainingSession> = emptyList(),
    val videos: List<VideoItem> = emptyList()
)

// ---------------------------------------------------------------- JSON-Helfer
fun decodePhases(json: String): List<Phase> =
    runCatching { AppJson.decodeFromString<List<Phase>>(json) }.getOrDefault(emptyList())

fun encodePhases(phases: List<Phase>): String = AppJson.encodeToString(phases)

fun decodeRoles(json: String): List<RoleAssignment> =
    runCatching { AppJson.decodeFromString<List<RoleAssignment>>(json) }.getOrDefault(emptyList())

fun encodeRoles(roles: List<RoleAssignment>): String = AppJson.encodeToString(roles)

fun decodeScribbles(json: String): List<Scribble> =
    runCatching { AppJson.decodeFromString<List<Scribble>>(json) }.getOrDefault(emptyList())

fun encodeScribbles(s: List<Scribble>): String = AppJson.encodeToString(s)

fun decodeItems(json: String): List<ExItem> =
    runCatching { AppJson.decodeFromString<List<ExItem>>(json) }.getOrDefault(emptyList())

fun encodeItems(items: List<ExItem>): String = AppJson.encodeToString(items)

fun decodeEntries(json: String): List<SessionEntry> =
    runCatching { AppJson.decodeFromString<List<SessionEntry>>(json) }.getOrDefault(emptyList())

fun encodeEntries(e: List<SessionEntry>): String = AppJson.encodeToString(e)

// ---------------------------------------------------------------- Material
fun materialCounts(items: List<ExItem>): Map<String, Int> {
    val materialKeys = ITEM_TYPES.filter { it.isMaterial }.map { it.key }.toSet()
    return items.filter { it.type in materialKeys }.groupingBy { it.type }.eachCount()
}

fun materialText(counts: Map<String, Int>): String =
    ITEM_TYPES.filter { (counts[it.key] ?: 0) > 0 }
        .joinToString(", ") { "${counts[it.key]}× ${it.label}" }

// ---------------------------------------------------------------- Aufstellungen erzeugen
/** "4-2-3-1" -> [4,2,3,1]; bei ungültiger Eingabe 4-4-2. */
fun parseSystem(s: String): List<Int> {
    val parts = s.split('-', ' ', ',').mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..6 }
    return if (parts.isNotEmpty() && parts.sum() == 10) parts else listOf(4, 4, 2)
}

fun buildTokens(system: String, opponent: Boolean): List<Token> {
    val rows = listOf(1) + parseSystem(system)
    val tokens = mutableListOf<Token>()
    var n = 1
    rows.forEachIndexed { r, count ->
        val own = 0.93f - r * (0.43f / (rows.size - 1))
        val y = if (opponent) 1f - own else own
        for (k in 0 until count) {
            tokens += Token(label = n.toString(), x = (k + 1f) / (count + 1f), y = y, opponent = opponent)
            n++
        }
    }
    return tokens
}
