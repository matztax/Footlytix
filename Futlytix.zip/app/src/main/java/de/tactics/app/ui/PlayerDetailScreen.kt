@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.tactics.app.MainViewModel

/** Spielerprofil: Stammdaten, Stärken, Schwächen, Ziele, Notizen und Bewertung. */
@Composable
fun PlayerDetailScreen(vm: MainViewModel, id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val players by vm.players.collectAsStateWithLifecycle()
    val p = players.firstOrNull { it.id == id }

    if (p == null) {
        Column(Modifier.padding(16.dp)) {
            TextButton(onClick = onBack) { Text("← Zurück") }
            Text("Spieler nicht gefunden.")
        }
        return
    }

    var name by remember(p.id) { mutableStateOf(p.name) }
    var number by remember(p.id) { mutableStateOf(p.number.toString()) }
    var position by remember(p.id) { mutableStateOf(p.position) }
    var strengths by remember(p.id) { mutableStateOf(p.strengths) }
    var weaknesses by remember(p.id) { mutableStateOf(p.weaknesses) }
    var goals by remember(p.id) { mutableStateOf(p.goals) }
    var notes by remember(p.id) { mutableStateOf(p.notes) }
    var rTech by remember(p.id) { mutableStateOf(p.ratingTechnik) }
    var rTakt by remember(p.id) { mutableStateOf(p.ratingTaktik) }
    var rAth by remember(p.id) { mutableStateOf(p.ratingAthletik) }
    var rMent by remember(p.id) { mutableStateOf(p.ratingMental) }

    val rated = listOf(rTech, rTakt, rAth, rMent).filter { it > 0 }
    val avg = if (rated.isEmpty()) null else rated.average()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Zurück") }
            Spacer(Modifier.weight(1f))
            Button(onClick = {
                vm.savePlayer(
                    p.copy(
                        name = name.trim().ifBlank { p.name },
                        number = number.toIntOrNull() ?: 0,
                        position = position.trim(),
                        strengths = strengths.trim(),
                        weaknesses = weaknesses.trim(),
                        goals = goals.trim(),
                        notes = notes.trim(),
                        ratingTechnik = rTech,
                        ratingTaktik = rTakt,
                        ratingAthletik = rAth,
                        ratingMental = rMent
                    )
                )
                Toast.makeText(ctx, "Gespeichert", Toast.LENGTH_SHORT).show()
            }) { Text("Speichern") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                number, { number = it.filter(Char::isDigit).take(2) },
                label = { Text("Nr.") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(90.dp)
            )
            OutlinedTextField(
                name, { name = it }, label = { Text("Name") }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }
        OutlinedTextField(
            position, { position = it }, label = { Text("Position") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Bewertung", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        RatingRow("Technik", rTech) { rTech = it }
        RatingRow("Taktik", rTakt) { rTakt = it }
        RatingRow("Athletik", rAth) { rAth = it }
        RatingRow("Mentalität", rMent) { rMent = it }
        Text(
            if (avg == null) "Gesamt: noch nicht bewertet" else "Gesamt: ★ " + "%.1f".format(avg) + " von 5",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            strengths, { strengths = it }, label = { Text("Stärken") },
            minLines = 2, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            weaknesses, { weaknesses = it }, label = { Text("Schwächen") },
            minLines = 2, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            goals, { goals = it }, label = { Text("Ziele / Entwicklung") },
            minLines = 2, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            notes, { notes = it }, label = { Text("Weitere Notizen") },
            minLines = 3, modifier = Modifier.fillMaxWidth()
        )
    }
}
