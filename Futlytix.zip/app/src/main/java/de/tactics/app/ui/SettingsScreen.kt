@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.tactics.app.AppPrefs
import de.tactics.app.AutoBackup
import de.tactics.app.Exporter
import de.tactics.app.MainViewModel
import de.tactics.app.Security
import de.tactics.app.findFragmentActivity
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx.findFragmentActivity()
    val scope = rememberCoroutineScope()
    val prefs = remember { AppPrefs(ctx) }
    var lock by remember { mutableStateOf(prefs.lockEnabled) }
    var auto by remember { mutableStateOf(prefs.autoBackup) }
    var folder by remember { mutableStateOf(prefs.backupFolder) }
    var lastTime by remember { mutableStateOf(prefs.lastBackupTime) }
    var files by remember { mutableStateOf(AutoBackup.list(ctx)) }
    var restoreFile by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            prefs.backupFolder = uri.toString()
            folder = uri.toString()
        }
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Zurück") }
        }
        Text("Sicherheit & Backup", style = MaterialTheme.typography.titleLarge)

        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("App-Sperre", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Beim Öffnen und nach einer Minute im Hintergrund wird Fingerabdruck, Gesicht oder die PIN bzw. das Muster deines Geräts verlangt. Die Daten der Sperre liest die App nie selbst, das übernimmt Android.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(
                    checked = lock,
                    onCheckedChange = { want ->
                        if (activity == null) {
                            toast("Sperre ist hier nicht verfügbar.")
                        } else if (want) {
                            Security.prompt(
                                activity, "Sperre aktivieren",
                                onSuccess = { prefs.lockEnabled = true; lock = true },
                                onFail = { toast(it) }
                            )
                        } else {
                            Security.prompt(
                                activity, "Sperre ausschalten",
                                onSuccess = { prefs.lockEnabled = false; lock = false },
                                onFail = { toast(it) }
                            )
                        }
                    }
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Automatisches Backup", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Einmal pro Tag beim Start; die letzten 7 Sicherungen bleiben auf dem Gerät erhalten.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = auto, onCheckedChange = { auto = it; prefs.autoBackup = it })
                }
                Text(
                    "Letztes Backup: " + (if (lastTime == 0L) "noch nie" else formatDate(lastTime) + " " +
                        java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY).format(java.util.Date(lastTime))),
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(
                    enabled = !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            val f = vm.backupNow()
                            busy = false
                            lastTime = prefs.lastBackupTime
                            files = AutoBackup.list(ctx)
                            toast(if (f != null) "Backup gespeichert" else "Backup fehlgeschlagen")
                        }
                    }
                ) { Text(if (busy) "Sichere …" else "Jetzt sichern") }

                Text(
                    "Zusätzlicher Ordner: " + (folder?.let { Uri.parse(it).lastPathSegment ?: it } ?: "nicht gewählt"),
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Ordner wählen") }
                    if (folder != null) {
                        OutlinedButton(onClick = { prefs.backupFolder = null; folder = null }) { Text("Entfernen") }
                    }
                }
                Text(
                    "Mit einem Ordner (z. B. Google Drive oder SD-Karte) liegt jede Sicherung zusätzlich außerhalb der App. Android kann die App-Daten außerdem über die Geräte-Sicherung von Google sichern, wenn diese eingeschaltet ist.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Text("Gespeicherte Sicherungen", style = MaterialTheme.typography.titleMedium)
        if (files.isEmpty()) Text("Noch keine automatische Sicherung vorhanden.", style = MaterialTheme.typography.bodySmall)
        files.forEach { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name.removePrefix("futlytix-").removeSuffix(".json"), style = MaterialTheme.typography.titleSmall)
                        Text("${f.length() / 1024} KB", style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = {
                        Exporter.attempt(ctx) { Exporter.share(ctx, f, "application/json", "Backup teilen") }
                    }) { Text("Teilen") }
                    TextButton(onClick = { restoreFile = f }) { Text("Wiederherstellen") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    restoreFile?.let { f ->
        AlertDialog(
            onDismissRequest = { restoreFile = null },
            title = { Text("Backup wiederherstellen?") },
            text = { Text("Alle aktuellen Daten werden durch den Stand dieser Sicherung ersetzt.") },
            confirmButton = {
                TextButton(onClick = {
                    restoreFile = null
                    scope.launch {
                        val msg = try {
                            val text = withContext(Dispatchers.IO) { f.readText() }
                            vm.importJson(text)
                            "Backup wiederhergestellt"
                        } catch (e: Exception) {
                            "Wiederherstellung fehlgeschlagen: " + (e.message ?: "")
                        }
                        toast(msg)
                    }
                }) { Text("Wiederherstellen") }
            },
            dismissButton = { TextButton(onClick = { restoreFile = null }) { Text("Abbrechen") } }
        )
    }
}
