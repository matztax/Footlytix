package de.tactics.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tägliche automatische Sicherung: intern (letzte 7 Tage) und optional in einen gewählten Ordner. */
object AutoBackup {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "backups").apply { mkdirs() }

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.GERMANY).format(Date())

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.name.endsWith(".json") }?.sortedByDescending { it.name } ?: emptyList()

    fun write(ctx: Context, json: String): File {
        val file = File(dir(ctx), "futlytix-" + today() + ".json")
        file.writeText(json)
        list(ctx).drop(7).forEach { it.delete() }
        copyToFolder(ctx, file)
        return file
    }

    private fun copyToFolder(ctx: Context, file: File) {
        val folder = AppPrefs(ctx).backupFolder ?: return
        runCatching {
            val tree = DocumentFile.fromTreeUri(ctx, Uri.parse(folder)) ?: return
            tree.findFile(file.name)?.delete()
            val target = tree.createFile("application/json", file.name) ?: return
            ctx.contentResolver.openOutputStream(target.uri)?.use { it.write(file.readBytes()) }
        }
    }
}
