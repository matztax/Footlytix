package de.tactics.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import de.tactics.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val dao = db.dao()

    private fun <T> Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val players = dao.observePlayers().state(emptyList())
    val formations = dao.observeFormations().state(emptyList())
    val setPieces = dao.observeSetPieces().state(emptyList())
    val annotations = dao.observeAnnotations().state(emptyList())
    val briefings = dao.observeBriefings().state(emptyList())
    val exercises = dao.observeExercises().state(emptyList())
    val sessions = dao.observeSessions().state(emptyList())
    val videos = dao.observeVideos().state(emptyList())
    val clubs = dao.observeClubs().state(emptyList())
    val transfers = dao.observeTransfers().state(emptyList())
    val attributeDefs = dao.observeAttributeDefs().state(emptyList())
    val attributeLinks = dao.observeAttributeLinks().state(emptyList())
    val analyses = dao.observeAnalyses().state(emptyList())
    val seasons = dao.observeSeasons().state(emptyList())
    val matches = dao.observeMatches().state(emptyList())
    val matchPlayers = dao.observeMatchPlayers().state(emptyList())
    val availabilities = dao.observeAvailabilities().state(emptyList())
    val attendances = dao.observeAttendances().state(emptyList())
    val evaluations = dao.observeEvaluations().state(emptyList())
    val markers = dao.observeMarkers().state(emptyList())
    val matchEvents = dao.observeMatchEvents().state(emptyList())

    /** Spieler der eigenen Vereine (Kader für Aufstellung und Standards). */
    val ownPlayers = combine(players, clubs) { p, c ->
        val own = c.filter { it.isOwn }.map { it.id }.toSet()
        p.filter { it.clubId in own }
    }.state(emptyList())

    init {
        // Es soll immer mindestens einen eigenen Verein geben
        viewModelScope.launch {
            if (dao.countOwnClubs() == 0) dao.upsertClub(Club(name = "Mein Team", isOwn = true))
            if (dao.countSeasons() == 0) {
                val cal = java.util.Calendar.getInstance()
                val y = cal.get(java.util.Calendar.YEAR)
                val start = if (cal.get(java.util.Calendar.MONTH) >= java.util.Calendar.JULY) y else y - 1
                dao.upsertSeason(Season(name = "Saison $start/${(start + 1) % 100}", isActive = true))
            }
            // Tägliche automatische Sicherung
            delay(3000)
            runAutoBackupIfDue()
        }
    }

    // ------------------------------------------------------------ Auto-Backup
    private suspend fun runAutoBackupIfDue() {
        val prefs = AppPrefs(getApplication())
        if (prefs.autoBackup && prefs.lastBackupDay != AutoBackup.today()) backupNow()
    }

    /** Sichert sofort (intern und, falls gewählt, in den Backup-Ordner). */
    suspend fun backupNow(): java.io.File? {
        val app = getApplication<Application>()
        return runCatching {
            val json = exportJson()
            val file = withContext(Dispatchers.IO) { AutoBackup.write(app, json) }
            val prefs = AppPrefs(app)
            prefs.lastBackupDay = AutoBackup.today()
            prefs.lastBackupTime = System.currentTimeMillis()
            file
        }.getOrNull()
    }

    // Kader
    fun savePlayer(p: Player) { viewModelScope.launch { dao.upsertPlayer(p) } }
    fun deletePlayer(p: Player) {
        viewModelScope.launch {
            dao.deletePlayer(p)
            dao.deleteLinksFor("player", p.id)
            dao.deleteAnalysesFor("player", p.id)
            dao.deleteTransfersFor(p.id)
            dao.deleteMatchPlayersOfPlayer(p.id)
            dao.deleteAvailabilitiesOfPlayer(p.id)
            dao.deleteAttendancesOfPlayer(p.id)
            dao.deleteEvaluationsOfPlayer(p.id)
            dao.detachMarkersOfPlayer(p.id)
        }
    }

    // Vereine & Transfers
    fun saveClub(c: Club) { viewModelScope.launch { dao.upsertClub(c) } }
    fun deleteClub(c: Club) {
        viewModelScope.launch {
            dao.deleteClub(c)
            dao.detachPlayers(c.id)
            dao.clearOpponentRefs(c.id)
            dao.clearOwnRefs(c.id)
            dao.deleteLinksFor("club", c.id)
            dao.deleteAnalysesFor("club", c.id)
        }
    }

    /** Transfer: nur der Verein wechselt, Attribute, Analysen und Bewertungen bleiben am Spieler. */
    fun transferPlayer(p: Player, toClubId: Long, note: String) {
        viewModelScope.launch {
            val date = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date())
            dao.upsertTransfer(Transfer(playerId = p.id, fromClubId = p.clubId, toClubId = toClubId, date = date, note = note))
            dao.setPlayerClub(p.id, toClubId)
        }
    }

    // Attribute & Analysen
    fun saveAttributeDef(a: AttributeDef) { viewModelScope.launch { dao.upsertAttributeDef(a) } }
    fun deleteAttributeDef(a: AttributeDef) {
        viewModelScope.launch {
            dao.deleteAttributeDef(a)
            dao.deleteLinksOfAttribute(a.id)
        }
    }
    fun saveLink(l: AttributeLink) { viewModelScope.launch { dao.upsertAttributeLink(l) } }
    fun deleteLink(l: AttributeLink) { viewModelScope.launch { dao.deleteAttributeLink(l) } }

    /** Neues Attribut im Katalog anlegen (falls noch nicht vorhanden) und direkt zuordnen. */
    fun createAttributeAndLink(name: String, positive: Boolean, targetType: String, targetId: Long) {
        viewModelScope.launch {
            val existing = attributeDefs.value.firstOrNull { it.name.equals(name, ignoreCase = true) && it.positive == positive }
            val defId = existing?.id ?: dao.upsertAttributeDef(AttributeDef(name = name, positive = positive))
            val already = attributeLinks.value.any {
                it.targetType == targetType && it.targetId == targetId && it.attributeId == defId
            }
            if (!already) dao.upsertAttributeLink(AttributeLink(targetType = targetType, targetId = targetId, attributeId = defId))
        }
    }
    fun saveAnalysis(a: Analysis) { viewModelScope.launch { dao.upsertAnalysis(a) } }
    fun deleteAnalysis(a: Analysis) { viewModelScope.launch { dao.deleteAnalysis(a) } }

    // Aufstellungen
    fun createFormation(
        name: String,
        ownSystem: String,
        opponentSystem: String,
        ownClubId: Long,
        opponentClubId: Long,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val tokens = buildTokens(ownSystem, false) + buildTokens(opponentSystem, true)
            val phases = listOf(Phase("Phase 1", tokens))
            val id = dao.upsertFormation(
                Formation(
                    name = name,
                    phasesJson = encodePhases(phases),
                    ownClubId = ownClubId,
                    opponentClubId = opponentClubId
                )
            )
            onCreated(id)
        }
    }
    fun saveFormation(f: Formation) { viewModelScope.launch { dao.upsertFormation(f) } }
    fun deleteFormation(f: Formation) {
        viewModelScope.launch {
            dao.deleteFormation(f)
            dao.clearMatchFormation(f.id)
        }
    }

    // Standards
    fun saveSetPiece(s: SetPiece) { viewModelScope.launch { dao.upsertSetPiece(s) } }
    fun deleteSetPiece(s: SetPiece) { viewModelScope.launch { dao.deleteSetPiece(s) } }

    // Video-Zeichnungen
    fun saveAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.upsertAnnotation(a) } }
    fun deleteAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.deleteAnnotation(a) } }

    // Briefings
    fun saveBriefing(b: Briefing) { viewModelScope.launch { dao.upsertBriefing(b) } }
    fun deleteBriefing(b: Briefing) { viewModelScope.launch { dao.deleteBriefing(b) } }

    // Video-Bibliothek
    fun saveVideo(v: VideoItem) { viewModelScope.launch { dao.upsertVideo(v) } }
    fun deleteVideo(v: VideoItem) {
        viewModelScope.launch {
            dao.deleteVideo(v)
            dao.deleteMarkersOfVideo(v.id)
            if (dao.countVideosWithUri(v.uri) == 0) dao.deleteAnnotationsForUri(v.uri)
        }
    }

    // Übungen & Trainingseinheiten
    fun saveExercise(e: Exercise) { viewModelScope.launch { dao.upsertExercise(e) } }
    fun deleteExercise(e: Exercise) { viewModelScope.launch { dao.deleteExercise(e) } }
    fun saveSession(s: TrainingSession) { viewModelScope.launch { dao.upsertSession(s) } }
    fun deleteSession(s: TrainingSession) {
        viewModelScope.launch {
            dao.deleteSession(s)
            dao.deleteAttendancesOfSession(s.id)
        }
    }


    // Saisons & Spiele
    fun saveSeason(s: Season) { viewModelScope.launch { dao.upsertSeason(s) } }

    fun saveMatch(m: Match, rows: List<MatchPlayer>? = null, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = dao.upsertMatch(m)
            val realId = if (m.id > 0) m.id else id
            if (rows != null) {
                dao.deleteMatchPlayersFor(realId)
                dao.upsertMatchPlayers(rows.map { it.copy(id = 0, matchId = realId) })
            }
            onSaved(realId)
        }
    }

    fun deleteMatch(m: Match) {
        viewModelScope.launch {
            dao.deleteMatch(m)
            dao.deleteMatchPlayersFor(m.id)
            dao.deleteMatchEventsFor(m.id)
            dao.deleteAnalysesFor("match", m.id)
        }
    }

    // Verfügbarkeit
    fun saveAvailability(a: Availability) { viewModelScope.launch { dao.upsertAvailability(a) } }
    fun deleteAvailability(a: Availability) { viewModelScope.launch { dao.deleteAvailability(a) } }

    // Anwesenheit: status = "" entfernt den Eintrag
    fun setAttendance(sessionId: Long, playerId: Long, status: String) {
        viewModelScope.launch {
            val existing = attendances.value.firstOrNull { it.sessionId == sessionId && it.playerId == playerId }
            if (status.isEmpty()) {
                if (existing != null) dao.deleteAttendance(existing)
            } else {
                dao.upsertAttendance(Attendance(id = existing?.id ?: 0L, sessionId = sessionId, playerId = playerId, status = status))
            }
        }
    }

    fun setAttendanceForAll(sessionId: Long, playerIds: List<Long>, status: String) {
        viewModelScope.launch {
            playerIds.forEach { pid ->
                val existing = attendances.value.firstOrNull { it.sessionId == sessionId && it.playerId == pid }
                dao.upsertAttendance(Attendance(id = existing?.id ?: 0L, sessionId = sessionId, playerId = pid, status = status))
            }
        }
    }

    // Bewertungsverlauf
    fun saveEvaluation(e: Evaluation) { viewModelScope.launch { dao.upsertEvaluation(e) } }
    fun deleteEvaluation(e: Evaluation) { viewModelScope.launch { dao.deleteEvaluation(e) } }

    // Video-Marker
    fun saveMarker(m: VideoMarker) { viewModelScope.launch { dao.upsertMarker(m) } }
    fun deleteMarker(m: VideoMarker) { viewModelScope.launch { dao.deleteMarker(m) } }

    // ------------------------------------------------------------ Live-Modus (Spieltag)
    var liveMatchId by mutableLongStateOf(0L)
        private set
    var liveRunning by mutableStateOf(false)
        private set
    private var liveBaseMs = 0L
    private var liveStartedAt = 0L

    fun liveElapsedMs(): Long = liveBaseMs + (if (liveRunning) System.currentTimeMillis() - liveStartedAt else 0L)

    fun liveEnter(matchId: Long) {
        if (liveMatchId != matchId) {
            liveMatchId = matchId
            liveRunning = false
            liveBaseMs = 0L
        }
    }

    fun liveToggle() {
        if (liveRunning) {
            liveBaseMs = liveElapsedMs()
            liveRunning = false
        } else {
            liveStartedAt = System.currentTimeMillis()
            liveRunning = true
        }
    }

    fun liveAdjustMinutes(delta: Int) {
        liveBaseMs = (liveElapsedMs() + delta * 60_000L).coerceAtLeast(0L)
        if (liveRunning) liveStartedAt = System.currentTimeMillis()
    }

    fun addMatchEvent(e: MatchEvent) { viewModelScope.launch { dao.upsertMatchEvent(e) } }
    fun deleteMatchEvent(e: MatchEvent) { viewModelScope.launch { dao.deleteMatchEvent(e) } }

    /** Legt die Startelf aus der verknüpften Aufstellung an, falls noch keine Einsätze existieren. */
    fun ensureLineup(match: Match) {
        viewModelScope.launch {
            val has = matchPlayers.value.any { it.matchId == match.id }
            if (has || match.formationId <= 0) return@launch
            val f = formations.value.firstOrNull { it.id == match.formationId } ?: return@launch
            val ph = decodePhases(f.phasesJson).firstOrNull() ?: return@launch
            val rows = ph.tokens.filter { !it.opponent && it.playerId >= 0 }
                .map { MatchPlayer(matchId = match.id, playerId = it.playerId, started = true) }
            if (rows.isNotEmpty()) dao.upsertMatchPlayers(rows)
        }
    }

    /** Rechnet Ergebnis, Minuten, Tore, Vorlagen, Karten und Verletzungen aus den Ereignissen aus. */
    fun finishMatch(match: Match, endMinute: Int, onDone: () -> Unit) {
        viewModelScope.launch {
            val events = matchEvents.value.filter { it.matchId == match.id }.sortedWith(compareBy<MatchEvent>({ it.minute }, { it.id }))
            val rows = matchPlayers.value.filter { it.matchId == match.id }.associateBy { it.playerId }.toMutableMap()
            val inAt = mutableMapOf<Long, Int>()
            val offAt = mutableMapOf<Long, Int>()
            events.forEach { e ->
                when (e.type) {
                    "sub" -> {
                        offAt[e.playerId] = e.minute
                        if (e.otherPlayerId > 0) inAt[e.otherPlayerId] = e.minute
                    }
                    "red" -> offAt[e.playerId] = e.minute
                }
                listOf(e.playerId, e.otherPlayerId).filter { it > 0 }.forEach { pid ->
                    if (!rows.containsKey(pid)) rows[pid] = MatchPlayer(matchId = match.id, playerId = pid)
                }
            }
            val result = rows.values.map { r ->
                val start: Int? = if (r.started) 0 else inAt[r.playerId]
                val minutes = if (start == null) r.minutes
                else (minOf(offAt[r.playerId] ?: endMinute, endMinute) - start).coerceAtLeast(0)
                r.copy(
                    matchId = match.id,
                    minutes = minutes,
                    goals = events.count { it.type == "goal" && it.playerId == r.playerId },
                    assists = events.count { it.type == "goal" && it.otherPlayerId == r.playerId },
                    yellow = events.count { it.type == "yellow" && it.playerId == r.playerId },
                    red = events.count { it.type == "red" && it.playerId == r.playerId },
                    injured = r.injured || events.any { it.type == "injury" && it.playerId == r.playerId }
                )
            }
            val updated = match.copy(
                played = true,
                goalsFor = events.count { it.type == "goal" },
                goalsAgainst = events.count { it.type == "conceded" }
            )
            dao.upsertMatch(updated)
            dao.deleteMatchPlayersFor(match.id)
            dao.upsertMatchPlayers(result.map { it.copy(id = 0) })
            liveRunning = false
            onDone()
        }
    }

    // ------------------------------------------------------------ Import
    private fun dayKey(ms: Long): String =
        java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date(ms))

    fun importPlayers(clubId: Long, items: List<ImportedPlayer>, onDone: (Int, Int) -> Unit) {
        viewModelScope.launch {
            val existing = players.value.filter { it.clubId == clubId }.map { it.name.lowercase().trim() }.toMutableSet()
            val toAdd = mutableListOf<Player>()
            var skipped = 0
            items.forEach { ip ->
                val key = ip.name.lowercase().trim()
                if (key in existing) {
                    skipped++
                } else {
                    existing += key
                    toAdd += Player(name = ip.name.trim(), number = ip.number, position = ip.position.trim(), clubId = clubId)
                }
            }
            if (toAdd.isNotEmpty()) dao.upsertPlayers(toAdd)
            onDone(toAdd.size, skipped)
        }
    }

    fun importMatches(
        seasonId: Long,
        ownClubId: Long,
        items: List<ImportedMatch>,
        createClubs: Boolean,
        onDone: (Int, Int) -> Unit
    ) {
        viewModelScope.launch {
            val clubList = clubs.value.toMutableList()
            val seen = matches.value.map { m ->
                val name = clubList.firstOrNull { it.id == m.opponentClubId }?.name ?: m.opponentName
                dayKey(m.dateMillis) + "|" + name.lowercase().trim()
            }.toMutableSet()
            val toAdd = mutableListOf<Match>()
            var skipped = 0
            for (im in items) {
                val key = im.opponent.lowercase().trim()
                if (key.isEmpty()) { skipped++; continue }
                val dup = dayKey(im.dateMillis) + "|" + key
                if (dup in seen) { skipped++; continue }
                seen += dup
                var club = clubList.firstOrNull { !it.isOwn && it.name.lowercase().trim() == key }
                if (club == null && createClubs) {
                    val newId = dao.upsertClub(Club(name = im.opponent.trim()))
                    val created = Club(id = newId, name = im.opponent.trim())
                    clubList += created
                    club = created
                }
                toAdd += Match(
                    seasonId = seasonId,
                    dateMillis = im.dateMillis,
                    ownClubId = ownClubId,
                    opponentClubId = club?.id ?: 0L,
                    opponentName = if (club == null) im.opponent.trim() else "",
                    home = im.home
                )
            }
            if (toAdd.isNotEmpty()) dao.upsertMatches(toAdd)
            onDone(toAdd.size, skipped)
        }
    }

    // Backup
    suspend fun exportJson(): String = AppJson.encodeToString(
        BackupBundle(
            players = dao.getPlayers(),
            formations = dao.getFormations(),
            setPieces = dao.getSetPieces(),
            annotations = dao.getAnnotations(),
            briefings = dao.getBriefings(),
            exercises = dao.getExercises(),
            sessions = dao.getSessions(),
            videos = dao.getVideos(),
            clubs = dao.getClubs(),
            transfers = dao.getTransfers(),
            attributeDefs = dao.getAttributeDefs(),
            attributeLinks = dao.getAttributeLinks(),
            analyses = dao.getAnalyses(),
            seasons = dao.getSeasons(),
            matches = dao.getMatches(),
            matchPlayers = dao.getMatchPlayers(),
            availabilities = dao.getAvailabilities(),
            attendances = dao.getAttendances(),
            evaluations = dao.getEvaluations(),
            markers = dao.getMarkers(),
            matchEvents = dao.getMatchEvents()
        )
    )

    suspend fun importJson(text: String) {
        val b = AppJson.decodeFromString<BackupBundle>(text)
        db.withTransaction {
            dao.clearPlayers(); dao.clearFormations(); dao.clearSetPieces()
            dao.clearAnnotations(); dao.clearBriefings()
            dao.clearExercises(); dao.clearSessions(); dao.clearVideos()
            dao.clearClubs(); dao.clearTransfers(); dao.clearAttributeDefs()
            dao.clearAttributeLinks(); dao.clearAnalyses()
            dao.clearSeasons(); dao.clearMatches(); dao.clearMatchPlayers(); dao.clearAvailabilities()
            dao.clearAttendances(); dao.clearEvaluations(); dao.clearMarkers(); dao.clearMatchEvents()
            dao.upsertPlayers(b.players)
            dao.upsertFormations(b.formations)
            dao.upsertSetPieces(b.setPieces)
            dao.upsertAnnotations(b.annotations)
            dao.upsertBriefings(b.briefings)
            dao.upsertExercises(b.exercises)
            dao.upsertSessions(b.sessions)
            dao.upsertVideos(b.videos)
            dao.upsertClubs(b.clubs)
            dao.upsertTransfers(b.transfers)
            dao.upsertAttributeDefs(b.attributeDefs)
            dao.upsertAttributeLinks(b.attributeLinks)
            dao.upsertAnalyses(b.analyses)
            dao.upsertSeasons(b.seasons)
            dao.upsertMatches(b.matches)
            dao.upsertMatchPlayers(b.matchPlayers)
            dao.upsertAvailabilities(b.availabilities)
            dao.upsertAttendances(b.attendances)
            dao.upsertEvaluations(b.evaluations)
            dao.upsertMarkers(b.markers)
            dao.upsertMatchEvents(b.matchEvents)
            if (dao.countSeasons() == 0) dao.upsertSeason(Season(name = "Saison", isActive = true))
            if (dao.countOwnClubs() == 0) {
                val ownId = dao.upsertClub(Club(name = "Mein Team", isOwn = true))
                // Ältere Backups kennen keine Vereine: alle Spieler gehören dann zum eigenen Team
                if (b.clubs.isEmpty()) dao.assignFreePlayers(ownId)
            }
        }
    }
}
