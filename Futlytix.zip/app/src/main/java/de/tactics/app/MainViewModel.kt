package de.tactics.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import de.tactics.app.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val dao = db.dao()

    private fun <T> Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val players = dao.observePlayers().state(emptyList())
    val formations = dao.observeFormations().state(emptyList())
    val setPieces = dao.observeSetPieces().state(emptyList())
    val annotations = dao.observeAnnotations().state(emptyList())
    val briefings = dao.observeBriefings().state(emptyList())
    val exercises = dao.observeExercises().state(emptyList())
    val sessions = dao.observeSessions().state(emptyList())
    val videos = dao.observeVideos().state(emptyList())
    val clubs = dao.observeClubs().state(emptyList())
    val transfers = dao.observeTransfers().state(emptyList())
    val attributeDefs = dao.observeAttributeDefs().state(emptyList())
    val attributeLinks = dao.observeAttributeLinks().state(emptyList())
    val analyses = dao.observeAnalyses().state(emptyList())

    /** Spieler der eigenen Vereine (Kader für Aufstellung und Standards). */
    val ownPlayers = combine(players, clubs) { p, c ->
        val own = c.filter { it.isOwn }.map { it.id }.toSet()
        p.filter { it.clubId in own }
    }.state(emptyList())

    init {
        // Es soll immer mindestens einen eigenen Verein geben
        viewModelScope.launch {
            if (dao.countOwnClubs() == 0) dao.upsertClub(Club(name = "Mein Team", isOwn = true))
        }
    }

    // Kader
    fun savePlayer(p: Player) { viewModelScope.launch { dao.upsertPlayer(p) } }
    fun deletePlayer(p: Player) {
        viewModelScope.launch {
            dao.deletePlayer(p)
            dao.deleteLinksFor("player", p.id)
            dao.deleteAnalysesFor("player", p.id)
            dao.deleteTransfersFor(p.id)
        }
    }

    // Vereine & Transfers
    fun saveClub(c: Club) { viewModelScope.launch { dao.upsertClub(c) } }
    fun deleteClub(c: Club) {
        viewModelScope.launch {
            dao.deleteClub(c)
            dao.detachPlayers(c.id)
            dao.clearOpponentRefs(c.id)
            dao.clearOwnRefs(c.id)
            dao.deleteLinksFor("club", c.id)
            dao.deleteAnalysesFor("club", c.id)
        }
    }

    /** Transfer: nur der Verein wechselt, Attribute, Analysen und Bewertungen bleiben am Spieler. */
    fun transferPlayer(p: Player, toClubId: Long, note: String) {
        viewModelScope.launch {
            val date = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date())
            dao.upsertTransfer(Transfer(playerId = p.id, fromClubId = p.clubId, toClubId = toClubId, date = date, note = note))
            dao.setPlayerClub(p.id, toClubId)
        }
    }

    // Attribute & Analysen
    fun saveAttributeDef(a: AttributeDef) { viewModelScope.launch { dao.upsertAttributeDef(a) } }
    fun deleteAttributeDef(a: AttributeDef) {
        viewModelScope.launch {
            dao.deleteAttributeDef(a)
            dao.deleteLinksOfAttribute(a.id)
        }
    }
    fun saveLink(l: AttributeLink) { viewModelScope.launch { dao.upsertAttributeLink(l) } }
    fun deleteLink(l: AttributeLink) { viewModelScope.launch { dao.deleteAttributeLink(l) } }

    /** Neues Attribut im Katalog anlegen (falls noch nicht vorhanden) und direkt zuordnen. */
    fun createAttributeAndLink(name: String, positive: Boolean, targetType: String, targetId: Long) {
        viewModelScope.launch {
            val existing = attributeDefs.value.firstOrNull { it.name.equals(name, ignoreCase = true) && it.positive == positive }
            val defId = existing?.id ?: dao.upsertAttributeDef(AttributeDef(name = name, positive = positive))
            val already = attributeLinks.value.any {
                it.targetType == targetType && it.targetId == targetId && it.attributeId == defId
            }
            if (!already) dao.upsertAttributeLink(AttributeLink(targetType = targetType, targetId = targetId, attributeId = defId))
        }
    }
    fun saveAnalysis(a: Analysis) { viewModelScope.launch { dao.upsertAnalysis(a) } }
    fun deleteAnalysis(a: Analysis) { viewModelScope.launch { dao.deleteAnalysis(a) } }

    // Aufstellungen
    fun createFormation(
        name: String,
        ownSystem: String,
        opponentSystem: String,
        ownClubId: Long,
        opponentClubId: Long,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val tokens = buildTokens(ownSystem, false) + buildTokens(opponentSystem, true)
            val phases = listOf(Phase("Phase 1", tokens))
            val id = dao.upsertFormation(
                Formation(
                    name = name,
                    phasesJson = encodePhases(phases),
                    ownClubId = ownClubId,
                    opponentClubId = opponentClubId
                )
            )
            onCreated(id)
        }
    }
    fun saveFormation(f: Formation) { viewModelScope.launch { dao.upsertFormation(f) } }
    fun deleteFormation(f: Formation) { viewModelScope.launch { dao.deleteFormation(f) } }

    // Standards
    fun saveSetPiece(s: SetPiece) { viewModelScope.launch { dao.upsertSetPiece(s) } }
    fun deleteSetPiece(s: SetPiece) { viewModelScope.launch { dao.deleteSetPiece(s) } }

    // Video-Zeichnungen
    fun saveAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.upsertAnnotation(a) } }
    fun deleteAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.deleteAnnotation(a) } }

    // Briefings
    fun saveBriefing(b: Briefing) { viewModelScope.launch { dao.upsertBriefing(b) } }
    fun deleteBriefing(b: Briefing) { viewModelScope.launch { dao.deleteBriefing(b) } }

    // Video-Bibliothek
    fun saveVideo(v: VideoItem) { viewModelScope.launch { dao.upsertVideo(v) } }
    fun deleteVideo(v: VideoItem) {
        viewModelScope.launch {
            dao.deleteVideo(v)
            if (dao.countVideosWithUri(v.uri) == 0) dao.deleteAnnotationsForUri(v.uri)
        }
    }

    // Übungen & Trainingseinheiten
    fun saveExercise(e: Exercise) { viewModelScope.launch { dao.upsertExercise(e) } }
    fun deleteExercise(e: Exercise) { viewModelScope.launch { dao.deleteExercise(e) } }
    fun saveSession(s: TrainingSession) { viewModelScope.launch { dao.upsertSession(s) } }
    fun deleteSession(s: TrainingSession) { viewModelScope.launch { dao.deleteSession(s) } }

    // Backup
    suspend fun exportJson(): String = AppJson.encodeToString(
        BackupBundle(
            players = dao.getPlayers(),
            formations = dao.getFormations(),
            setPieces = dao.getSetPieces(),
            annotations = dao.getAnnotations(),
            briefings = dao.getBriefings(),
            exercises = dao.getExercises(),
            sessions = dao.getSessions(),
            videos = dao.getVideos(),
            clubs = dao.getClubs(),
            transfers = dao.getTransfers(),
            attributeDefs = dao.getAttributeDefs(),
            attributeLinks = dao.getAttributeLinks(),
            analyses = dao.getAnalyses()
        )
    )

    suspend fun importJson(text: String) {
        val b = AppJson.decodeFromString<BackupBundle>(text)
        db.withTransaction {
            dao.clearPlayers(); dao.clearFormations(); dao.clearSetPieces()
            dao.clearAnnotations(); dao.clearBriefings()
            dao.clearExercises(); dao.clearSessions(); dao.clearVideos()
            dao.clearClubs(); dao.clearTransfers(); dao.clearAttributeDefs()
            dao.clearAttributeLinks(); dao.clearAnalyses()
            dao.upsertPlayers(b.players)
            dao.upsertFormations(b.formations)
            dao.upsertSetPieces(b.setPieces)
            dao.upsertAnnotations(b.annotations)
            dao.upsertBriefings(b.briefings)
            dao.upsertExercises(b.exercises)
            dao.upsertSessions(b.sessions)
            dao.upsertVideos(b.videos)
            dao.upsertClubs(b.clubs)
            dao.upsertTransfers(b.transfers)
            dao.upsertAttributeDefs(b.attributeDefs)
            dao.upsertAttributeLinks(b.attributeLinks)
            dao.upsertAnalyses(b.analyses)
            if (dao.countOwnClubs() == 0) {
                val ownId = dao.upsertClub(Club(name = "Mein Team", isOwn = true))
                // Ältere Backups kennen keine Vereine: alle Spieler gehören dann zum eigenen Team
                if (b.clubs.isEmpty()) dao.assignFreePlayers(ownId)
            }
        }
    }
}
