@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalTextApi::class)

package de.tactics.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.tactics.app.MainViewModel
import de.tactics.app.data.Phase
import de.tactics.app.data.Player
import de.tactics.app.data.Token
import de.tactics.app.data.decodePhases
import de.tactics.app.data.encodePhases

@Composable
fun FormationScreen(vm: MainViewModel) {
    val formations by vm.formations.collectAsStateWithLifecycle()
    val squad by vm.players.collectAsStateWithLifecycle()
    var selectedId by rememberSaveable { mutableStateOf(-1L) }
    var phaseIdx by rememberSaveable { mutableStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    var pickIndex by remember { mutableIntStateOf(-1) }

    val selected = formations.firstOrNull { it.id == selectedId } ?: formations.firstOrNull()
    val phases = remember(selected?.id, selected?.phasesJson) {
        selected?.let { decodePhases(it.phasesJson) } ?: emptyList()
    }
    val idx = phaseIdx.coerceIn(0, (phases.size - 1).coerceAtLeast(0))

    Column(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            formations.forEach { f ->
                FilterChip(
                    selected = f.id == selected?.id,
                    onClick = { selectedId = f.id; phaseIdx = 0 },
                    label = { Text(f.name) }
                )
            }
            AssistChip(onClick = { showNew = true }, label = { Text("+ Neue Aufstellung") })
        }

        if (selected == null || phases.isEmpty()) {
            Text("Lege eine Aufstellung an (z. B. 4-2-3-1 gegen 3-5-2). Danach tippst du auf eine Figur, um einen Spieler aus dem Kader zuzuweisen, und verschiebst sie per Finger.")
        } else {
            val tokens = phases[idx].tokens
            val assigned = tokens.filter { !it.opponent && it.playerId >= 0 }.map { it.playerId }.toSet()
            val bench = squad.filter { it.id !in assigned }

            fun saveTokens(t: List<Token>) {
                val updated = phases.toMutableList().also { it[idx] = it[idx].copy(tokens = t) }
                vm.saveFormation(selected.copy(phasesJson = encodePhases(updated)))
            }

            fun autoFill() {
                val free = squad.filter { it.id !in assigned }.toMutableList()
                val updated = tokens.mapIndexed { i, t ->
                    if (t.opponent || t.playerId >= 0 || free.isEmpty()) {
                        t
                    } else {
                        val gk = free.indexOfFirst { p ->
                            val pos = p.position.lowercase()
                            pos.startsWith("tw") || pos.startsWith("gk") || pos.contains("tor")
                        }
                        val pick = if (i == 0 && gk >= 0) free.removeAt(gk) else free.removeAt(0)
                        t.copy(playerId = pick.id)
                    }
                }
                saveTokens(updated)
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                phases.forEachIndexed { i, p ->
                    FilterChip(selected = i == idx, onClick = { phaseIdx = i }, label = { Text(p.name) })
                }
            }

            PitchBoard(
                tokens = tokens,
                players = squad,
                onChange = { saveTokens(it) },
                onTokenTap = { pickIndex = it },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )

            Text(
                if (squad.isEmpty()) "Kader ist leer – lege zuerst Spieler im Tab „Kader“ an."
                else if (bench.isEmpty()) "Alle Spieler sind aufgestellt."
                else "Bank: " + bench.joinToString(", ") { "${it.number} ${it.name}" },
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall
            )

            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    enabled = squad.isNotEmpty(),
                    onClick = { autoFill() }
                ) { Text("Kader zuweisen") }
                OutlinedButton(onClick = {
                    saveTokens(tokens.map { if (it.opponent) it else it.copy(playerId = -1L) })
                }) { Text("Spieler leeren") }
                Button(onClick = {
                    val copy = Phase("Phase ${phases.size + 1}", tokens)
                    vm.saveFormation(selected.copy(phasesJson = encodePhases(phases + copy)))
                    phaseIdx = phases.size
                }) { Text("Phase +") }
                OutlinedButton(
                    enabled = phases.size > 1,
                    onClick = {
                        val updated = phases.toMutableList().also { it.removeAt(idx) }
                        vm.saveFormation(selected.copy(phasesJson = encodePhases(updated)))
                        phaseIdx = 0
                    }
                ) { Text("Phase löschen") }
                OutlinedButton(onClick = { vm.deleteFormation(selected); selectedId = -1L; phaseIdx = 0 }) {
                    Text("Aufstellung löschen")
                }
            }

            if (pickIndex in tokens.indices) {
                val token = tokens[pickIndex]
                TokenDialog(
                    token = token,
                    players = squad,
                    assigned = assigned,
                    onDismiss = { pickIndex = -1 },
                    onPick = { pid ->
                        val at = pickIndex
                        saveTokens(
                            tokens.mapIndexed { i, t ->
                                when {
                                    i == at -> t.copy(playerId = pid)
                                    !t.opponent && pid >= 0 && t.playerId == pid -> t.copy(playerId = -1L)
                                    else -> t
                                }
                            }
                        )
                        pickIndex = -1
                    },
                    onLabel = { text ->
                        val at = pickIndex
                        saveTokens(tokens.mapIndexed { i, t -> if (i == at) t.copy(label = text) else t })
                        pickIndex = -1
                    }
                )
            }
        }
    }

    if (showNew) {
        NewFormationDialog(
            onDismiss = { showNew = false },
            onCreate = { name, own, opp ->
                vm.createFormation(name, own, opp) { id -> selectedId = id; phaseIdx = 0 }
                showNew = false
            }
        )
    }
}

@Composable
private fun TokenDialog(
    token: Token,
    players: List<Player>,
    assigned: Set<Long>,
    onDismiss: () -> Unit,
    onPick: (Long) -> Unit,
    onLabel: (String) -> Unit
) {
    if (token.opponent) {
        var text by remember { mutableStateOf(token.label) }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Gegner beschriften") },
            text = {
                OutlinedTextField(
                    text, { text = it.take(12) },
                    label = { Text("z. B. 9 oder Nr. 10") }, singleLine = true
                )
            },
            confirmButton = { TextButton(onClick = { onLabel(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Spieler wählen") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (players.isEmpty()) Text("Lege zuerst Spieler im Tab „Kader“ an.")
                    TextButton(onClick = { onPick(-1L) }) { Text("– Platz frei lassen –") }
                    players.forEach { p ->
                        val used = p.id in assigned && p.id != token.playerId
                        Text(
                            "${p.number}  ${p.name}" +
                                (if (p.position.isNotBlank()) "  (${p.position})" else "") +
                                (if (used) "  – bereits aufgestellt" else ""),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(p.id) }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
        )
    }
}

@Composable
private fun NewFormationDialog(onDismiss: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var own by remember { mutableStateOf("4-2-3-1") }
    var opp by remember { mutableStateOf("4-4-2") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Aufstellung") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name (z. B. Spiel gegen TSV)") }, singleLine = true)
                OutlinedTextField(own, { own = it }, label = { Text("Eigenes System") }, singleLine = true)
                OutlinedTextField(opp, { opp = it }, label = { Text("Gegnerisches System") }, singleLine = true)
                Text("Systeme als Zahlen, die 10 ergeben (ohne Torwart), z. B. 4-3-3 oder 3-5-2.")
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onCreate(name.trim(), own, opp) }
            ) { Text("Anlegen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

private fun nearestToken(tokens: List<Token>, o: Offset, w: Float, h: Float, hit: Float): Int {
    var best = -1
    var bestDist = hit
    tokens.forEachIndexed { i, t ->
        val d = (Offset(t.x * w, t.y * h) - o).getDistance()
        if (d < bestDist) { bestDist = d; best = i }
    }
    return best
}

/** Taktikfeld: Figuren per Finger verschieben, Tippen wählt Spieler (eigene) bzw. Beschriftung (Gegner). */
@Composable
fun PitchBoard(
    tokens: List<Token>,
    players: List<Player>,
    onChange: (List<Token>) -> Unit,
    onTokenTap: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var local by remember(tokens) { mutableStateOf(tokens) }
    var dragIndex by remember { mutableIntStateOf(-1) }
    val measurer = rememberTextMeasurer()
    val labelStyle = remember { TextStyle(color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
    val nameStyle = remember { TextStyle(color = Color.White, fontSize = 10.sp) }
    val onChangeLatest by rememberUpdatedState(onChange)
    val onTapLatest by rememberUpdatedState(onTokenTap)
    val byId = remember(players) { players.associateBy { it.id } }

    Canvas(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .pointerInput(tokens) {
                detectTapGestures(onTap = { o ->
                    val i = nearestToken(local, o, size.width.toFloat(), size.height.toFloat(), 30.dp.toPx())
                    if (i >= 0) onTapLatest(i)
                })
            }
            .pointerInput(tokens) {
                val hit = 36.dp.toPx()
                detectDragGestures(
                    onDragStart = { o ->
                        dragIndex = nearestToken(local, o, size.width.toFloat(), size.height.toFloat(), hit)
                    },
                    onDragEnd = {
                        if (dragIndex >= 0) onChangeLatest(local)
                        dragIndex = -1
                    },
                    onDragCancel = { dragIndex = -1 },
                    onDrag = { change, delta ->
                        if (dragIndex >= 0) {
                            change.consume()
                            val t = local[dragIndex]
                            local = local.toMutableList().also {
                                it[dragIndex] = t.copy(
                                    x = (t.x + delta.x / size.width).coerceIn(0f, 1f),
                                    y = (t.y + delta.y / size.height).coerceIn(0f, 1f)
                                )
                            }
                        }
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val m = 8f
        val line = Color.White.copy(alpha = 0.8f)
        val sw = 3f

        drawRect(Color(0xFF2E7D32))
        drawRect(line, Offset(m, m), Size(w - 2 * m, h - 2 * m), style = Stroke(sw))
        drawLine(line, Offset(m, h / 2), Offset(w - m, h / 2), sw)
        drawCircle(line, h * 0.1f, center, style = Stroke(sw))
        val bw = w * 0.6f
        val bh = h * 0.16f
        drawRect(line, Offset((w - bw) / 2, m), Size(bw, bh), style = Stroke(sw))
        drawRect(line, Offset((w - bw) / 2, h - m - bh), Size(bw, bh), style = Stroke(sw))

        val r = 18.dp.toPx()
        local.forEach { t ->
            val c = Offset(t.x * w, t.y * h)
            val pl = if (!t.opponent && t.playerId >= 0) byId[t.playerId] else null
            val fill = when {
                t.opponent -> Color(0xFFD32F2F)
                pl != null -> Color(0xFF1976D2)
                else -> Color(0xFF1976D2).copy(alpha = 0.5f)
            }
            drawCircle(fill, r, c)
            drawCircle(Color.White, r, c, style = Stroke(2f))
            val label = pl?.number?.toString() ?: t.label
            val layout = measurer.measure(label, labelStyle)
            drawText(layout, topLeft = c - Offset(layout.size.width / 2f, layout.size.height / 2f))
            if (pl != null) {
                val nm = measurer.measure(pl.name.substringAfterLast(' ').take(10), nameStyle)
                drawText(nm, topLeft = Offset(c.x - nm.size.width / 2f, c.y + r + 2f))
            }
        }
    }
}
