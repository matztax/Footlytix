@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalTextApi::class)

package de.tactics.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.tactics.app.MainViewModel
import de.tactics.app.data.Briefing
import de.tactics.app.data.Club
import de.tactics.app.data.Phase
import de.tactics.app.data.Player
import de.tactics.app.data.Token
import de.tactics.app.data.buildTokens
import de.tactics.app.data.decodePhases
import de.tactics.app.data.encodePhases

@Composable
fun FormationScreen(vm: MainViewModel) {
    val formations by vm.formations.collectAsStateWithLifecycle()
    val allPlayers by vm.players.collectAsStateWithLifecycle()
    val ownPlayers by vm.ownPlayers.collectAsStateWithLifecycle()
    val clubs by vm.clubs.collectAsStateWithLifecycle()
    val defs by vm.attributeDefs.collectAsStateWithLifecycle()
    val links by vm.attributeLinks.collectAsStateWithLifecycle()
    val analyses by vm.analyses.collectAsStateWithLifecycle()
    var selectedId by rememberSaveable { mutableStateOf(-1L) }
    var phaseIdx by rememberSaveable { mutableStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    var showMatchup by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var pickIndex by remember { mutableIntStateOf(-1) }

    val selected = formations.firstOrNull { it.id == selectedId } ?: formations.firstOrNull()
    val phases = remember(selected?.id, selected?.phasesJson) {
        selected?.let { decodePhases(it.phasesJson) } ?: emptyList()
    }
    val idx = phaseIdx.coerceIn(0, (phases.size - 1).coerceAtLeast(0))

    Column(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            formations.forEach { f ->
                FilterChip(
                    selected = f.id == selected?.id,
                    onClick = { selectedId = f.id; phaseIdx = 0 },
                    label = { Text(f.name) }
                )
            }
            AssistChip(onClick = { showNew = true }, label = { Text("+ Neue Aufstellung") })
        }

        if (selected == null || phases.isEmpty()) {
            Text("Lege eine Aufstellung an und wähle dein Team und den Gegner aus der Datenbank. Danach tippst du auf eine Figur, um einen Spieler zuzuweisen, und verschiebst sie per Finger.")
        } else {
            val ownClub = clubs.firstOrNull { it.id == selected.ownClubId }
            val opponentClub = clubs.firstOrNull { it.id == selected.opponentClubId }
            val squad = if (ownClub != null) allPlayers.filter { it.clubId == ownClub.id } else ownPlayers
            val oppPlayers = if (opponentClub != null) allPlayers.filter { it.clubId == opponentClub.id } else emptyList()

            val tokens = phases[idx].tokens
            val assignedOwn = tokens.filter { !it.opponent && it.playerId >= 0 }.map { it.playerId }.toSet()
            val assignedOpp = tokens.filter { it.opponent && it.playerId >= 0 }.map { it.playerId }.toSet()
            val bench = squad.filter { it.id !in assignedOwn }

            fun saveTokens(t: List<Token>) {
                val updated = phases.toMutableList().also { it[idx] = it[idx].copy(tokens = t) }
                vm.saveFormation(selected.copy(phasesJson = encodePhases(updated)))
            }

            fun autoFill(opponent: Boolean, pool: List<Player>, assigned: Set<Long>) {
                val free = pool.filter { it.id !in assigned }.sortedBy { it.number }.toMutableList()
                var first = true
                val updated = tokens.map { t ->
                    if (t.opponent != opponent || t.playerId >= 0 || free.isEmpty()) {
                        t
                    } else {
                        val gk = free.indexOfFirst { p ->
                            val pos = p.position.lowercase()
                            pos.startsWith("tw") || pos.startsWith("gk") || pos.contains("tor")
                        }
                        // erster Platz der Seite = Torwart
                        val pick = if (first && gk >= 0) free.removeAt(gk) else free.removeAt(0)
                        first = false
                        t.copy(playerId = pick.id)
                    }
                }
                saveTokens(updated)
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        (ownClub?.name ?: "Eigenes Team") + "  vs.  " + (opponentClub?.name ?: "Gegner offen"),
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (opponentClub != null && opponentClub.system.isNotBlank()) {
                        Text("Gegner-System: ${opponentClub.system}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                OutlinedButton(onClick = { showMatchup = true }) { Text("Teams") }
                Button(enabled = opponentClub != null, onClick = { showInfo = true }) { Text("Gegner-Info") }
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                phases.forEachIndexed { i, p ->
                    FilterChip(selected = i == idx, onClick = { phaseIdx = i }, label = { Text(p.name) })
                }
            }

            PitchBoard(
                tokens = tokens,
                players = allPlayers,
                onChange = { saveTokens(it) },
                onTokenTap = { pickIndex = it },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )

            Text(
                if (squad.isEmpty()) "Dein Team hat noch keine Spieler – lege sie im Tab „Datenbank“ an."
                else if (bench.isEmpty()) "Alle Spieler sind aufgestellt."
                else "Bank: " + bench.joinToString(", ") { "${it.number} ${it.name}" },
                style = MaterialTheme.typography.bodySmall
            )

            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    enabled = squad.isNotEmpty(),
                    onClick = { autoFill(false, squad, assignedOwn) }
                ) { Text("Kader zuweisen") }
                OutlinedButton(
                    enabled = oppPlayers.isNotEmpty(),
                    onClick = { autoFill(true, oppPlayers, assignedOpp) }
                ) { Text("Gegner zuweisen") }
                OutlinedButton(onClick = {
                    saveTokens(tokens.map { it.copy(playerId = -1L) })
                }) { Text("Spieler leeren") }
                Button(onClick = {
                    val copy = Phase("Phase ${phases.size + 1}", tokens)
                    vm.saveFormation(selected.copy(phasesJson = encodePhases(phases + copy)))
                    phaseIdx = phases.size
                }) { Text("Phase +") }
                OutlinedButton(
                    enabled = phases.size > 1,
                    onClick = {
                        val updated = phases.toMutableList().also { it.removeAt(idx) }
                        vm.saveFormation(selected.copy(phasesJson = encodePhases(updated)))
                        phaseIdx = 0
                    }
                ) { Text("Phase löschen") }
                OutlinedButton(onClick = { vm.deleteFormation(selected); selectedId = -1L; phaseIdx = 0 }) {
                    Text("Aufstellung löschen")
                }
            }

            if (pickIndex in tokens.indices) {
                val token = tokens[pickIndex]
                TokenDialog(
                    token = token,
                    players = if (token.opponent) oppPlayers else squad,
                    assigned = if (token.opponent) assignedOpp else assignedOwn,
                    onDismiss = { pickIndex = -1 },
                    onPick = { pid ->
                        val at = pickIndex
                        val side = tokens[at].opponent
                        saveTokens(
                            tokens.mapIndexed { i, t ->
                                when {
                                    i == at -> t.copy(playerId = pid)
                                    t.opponent == side && pid >= 0 && t.playerId == pid -> t.copy(playerId = -1L)
                                    else -> t
                                }
                            }
                        )
                        pickIndex = -1
                    },
                    onLabel = { text ->
                        val at = pickIndex
                        saveTokens(tokens.mapIndexed { i, t -> if (i == at) t.copy(label = text, playerId = -1L) else t })
                        pickIndex = -1
                    }
                )
            }

            if (showMatchup) {
                MatchupDialog(
                    clubs = clubs,
                    ownClubId = selected.ownClubId,
                    opponentClubId = selected.opponentClubId,
                    onDismiss = { showMatchup = false },
                    onSave = { ownId, oppId, applySystem ->
                        var updatedPhases = phases
                        val oppNew = clubs.firstOrNull { it.id == oppId }
                        if (applySystem && oppNew != null && oppNew.system.isNotBlank()) {
                            val fresh = buildTokens(oppNew.system, true)
                            updatedPhases = phases.map { ph ->
                                ph.copy(tokens = ph.tokens.filter { !it.opponent } + fresh)
                            }
                        }
                        vm.saveFormation(
                            selected.copy(
                                ownClubId = ownId,
                                opponentClubId = oppId,
                                phasesJson = encodePhases(updatedPhases)
                            )
                        )
                        showMatchup = false
                    }
                )
            }

            if (showInfo && opponentClub != null) {
                val featured = if (assignedOpp.isNotEmpty()) oppPlayers.filter { it.id in assignedOpp } else oppPlayers
                val report = buildOpponentReport(opponentClub, featured, defs, links, analyses)
                AlertDialog(
                    onDismissRequest = { showInfo = false },
                    title = { Text("Gegner-Info") },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) { Text(report) }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            vm.saveBriefing(Briefing(title = "Gegner: ${opponentClub.name}", text = report))
                            showInfo = false
                        }) { Text("Als Briefing speichern") }
                    },
                    dismissButton = { TextButton(onClick = { showInfo = false }) { Text("Schließen") } }
                )
            }
        }
    }

    if (showNew) {
        NewFormationDialog(
            clubs = clubs,
            onDismiss = { showNew = false },
            onCreate = { name, own, opp, ownId, oppId ->
                vm.createFormation(name, own, opp, ownId, oppId) { id -> selectedId = id; phaseIdx = 0 }
                showNew = false
            }
        )
    }
}

@Composable
private fun MatchupDialog(
    clubs: List<Club>,
    ownClubId: Long,
    opponentClubId: Long,
    onDismiss: () -> Unit,
    onSave: (Long, Long, Boolean) -> Unit
) {
    var ownId by remember { mutableStateOf(ownClubId) }
    var oppId by remember { mutableStateOf(opponentClubId) }
    var applySystem by remember { mutableStateOf(false) }
    val oppClub = clubs.firstOrNull { it.id == oppId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Teams wählen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Eigenes Team", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    clubs.filter { it.isOwn }.forEach { c ->
                        FilterChip(selected = ownId == c.id, onClick = { ownId = c.id }, label = { Text(c.name) })
                    }
                }
                Text("Gegner", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = oppId == 0L, onClick = { oppId = 0L }, label = { Text("offen") })
                    clubs.filter { !it.isOwn }.forEach { c ->
                        FilterChip(selected = oppId == c.id, onClick = { oppId = c.id }, label = { Text(c.name) })
                    }
                }
                if (clubs.none { !it.isOwn }) {
                    Text("Noch keine Gegner in der Datenbank. Lege sie im Tab „Datenbank“ unter „Vereine“ an.", style = MaterialTheme.typography.bodySmall)
                }
                if (oppClub != null && oppClub.system.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(
                            selected = applySystem,
                            onClick = { applySystem = !applySystem },
                            label = { Text("System ${oppClub.system} übernehmen") }
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(ownId, oppId, applySystem) }) { Text("Übernehmen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
private fun TokenDialog(
    token: Token,
    players: List<Player>,
    assigned: Set<Long>,
    onDismiss: () -> Unit,
    onPick: (Long) -> Unit,
    onLabel: (String) -> Unit
) {
    var text by remember { mutableStateOf(token.label) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (token.opponent) "Gegner-Position" else "Spieler wählen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (players.isEmpty()) {
                    Text(
                        if (token.opponent) "Für diesen Gegner sind keine Spieler gespeichert. Du kannst unten eine freie Beschriftung eingeben."
                        else "Lege zuerst Spieler im Tab „Datenbank“ an."
                    )
                }
                TextButton(onClick = { onPick(-1L) }) { Text("– Platz frei lassen –") }
                players.forEach { p ->
                    val used = p.id in assigned && p.id != token.playerId
                    Text(
                        "${p.number}  ${p.name}" +
                            (if (p.position.isNotBlank()) "  (${p.position})" else "") +
                            (if (used) "  – bereits aufgestellt" else ""),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(p.id) }
                            .padding(vertical = 12.dp)
                    )
                }
                if (token.opponent) {
                    OutlinedTextField(
                        text, { text = it.take(12) },
                        label = { Text("Freie Beschriftung, z. B. 9") },
                        singleLine = true,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            if (token.opponent) TextButton(onClick = { onLabel(text) }) { Text("Beschriftung speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
private fun NewFormationDialog(
    clubs: List<Club>,
    onDismiss: () -> Unit,
    onCreate: (String, String, String, Long, Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var own by remember { mutableStateOf("4-2-3-1") }
    var opp by remember { mutableStateOf("4-4-2") }
    var ownId by remember { mutableStateOf(clubs.firstOrNull { it.isOwn }?.id ?: 0L) }
    var oppId by remember { mutableStateOf(0L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Aufstellung") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name (z. B. Spiel gegen TSV)") }, singleLine = true)
                Text("Eigenes Team", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    clubs.filter { it.isOwn }.forEach { c ->
                        FilterChip(
                            selected = ownId == c.id,
                            onClick = { ownId = c.id; if (c.system.isNotBlank()) own = c.system },
                            label = { Text(c.name) }
                        )
                    }
                }
                OutlinedTextField(own, { own = it }, label = { Text("Eigenes System") }, singleLine = true)
                Text("Gegner aus der Datenbank", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = oppId == 0L, onClick = { oppId = 0L }, label = { Text("offen") })
                    clubs.filter { !it.isOwn }.forEach { c ->
                        FilterChip(
                            selected = oppId == c.id,
                            onClick = { oppId = c.id; if (c.system.isNotBlank()) opp = c.system },
                            label = { Text(c.name) }
                        )
                    }
                }
                OutlinedTextField(opp, { opp = it }, label = { Text("Gegnerisches System") }, singleLine = true)
                Text("Systeme als Zahlen, die 10 ergeben (ohne Torwart), z. B. 4-3-3 oder 3-5-2.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onCreate(name.trim(), own, opp, ownId, oppId) }
            ) { Text("Anlegen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

private fun nearestToken(tokens: List<Token>, o: Offset, w: Float, h: Float, hit: Float): Int {
    var best = -1
    var bestDist = hit
    tokens.forEachIndexed { i, t ->
        val d = (Offset(t.x * w, t.y * h) - o).getDistance()
        if (d < bestDist) { bestDist = d; best = i }
    }
    return best
}

/** Taktikfeld: Figuren per Finger verschieben, Tippen wählt Spieler (eigene) bzw. Beschriftung (Gegner). */
@Composable
fun PitchBoard(
    tokens: List<Token>,
    players: List<Player>,
    onChange: (List<Token>) -> Unit,
    onTokenTap: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var local by remember(tokens) { mutableStateOf(tokens) }
    var dragIndex by remember { mutableIntStateOf(-1) }
    val measurer = rememberTextMeasurer()
    val labelStyle = remember { TextStyle(color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
    val nameStyle = remember { TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
    val onChangeLatest by rememberUpdatedState(onChange)
    val onTapLatest by rememberUpdatedState(onTokenTap)
    val byId = remember(players) { players.associateBy { it.id } }

    Canvas(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .pointerInput(tokens) {
                detectTapGestures(onTap = { o ->
                    val i = nearestToken(local, o, size.width.toFloat(), size.height.toFloat(), 30.dp.toPx())
                    if (i >= 0) onTapLatest(i)
                })
            }
            .pointerInput(tokens) {
                val hit = 36.dp.toPx()
                detectDragGestures(
                    onDragStart = { o ->
                        dragIndex = nearestToken(local, o, size.width.toFloat(), size.height.toFloat(), hit)
                    },
                    onDragEnd = {
                        if (dragIndex >= 0) onChangeLatest(local)
                        dragIndex = -1
                    },
                    onDragCancel = { dragIndex = -1 },
                    onDrag = { change, delta ->
                        if (dragIndex >= 0) {
                            change.consume()
                            val t = local[dragIndex]
                            local = local.toMutableList().also {
                                it[dragIndex] = t.copy(
                                    x = (t.x + delta.x / size.width).coerceIn(0f, 1f),
                                    y = (t.y + delta.y / size.height).coerceIn(0f, 1f)
                                )
                            }
                        }
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val u = 1.dp.toPx()

        // Spielfeld: ruhiger Verlauf mit feinen Rasenstreifen
        drawRect(Brush.verticalGradient(listOf(Color(0xFF1D6B52), Color(0xFF14503E))))
        val stripes = 10
        for (i in 0 until stripes step 2) {
            drawRect(Color.White.copy(alpha = 0.035f), Offset(0f, h * i / stripes), Size(w, h / stripes))
        }

        // Linien: dünn und zurückhaltend
        val line = Color.White.copy(alpha = 0.55f)
        val sw = 1.8f * u
        val m = 10 * u
        drawRoundRect(line, Offset(m, m), Size(w - 2 * m, h - 2 * m), CornerRadius(6 * u), style = Stroke(sw))
        drawLine(line, Offset(m, h / 2), Offset(w - m, h / 2), sw)
        drawCircle(line, h * 0.09f, center, style = Stroke(sw))
        drawCircle(line, 2.5f * u, center)
        val bw = w * 0.58f
        val bh = h * 0.15f
        val gw = w * 0.26f
        val gh = h * 0.055f
        drawRect(line, Offset((w - bw) / 2, m), Size(bw, bh), style = Stroke(sw))
        drawRect(line, Offset((w - bw) / 2, h - m - bh), Size(bw, bh), style = Stroke(sw))
        drawRect(line, Offset((w - gw) / 2, m), Size(gw, gh), style = Stroke(sw))
        drawRect(line, Offset((w - gw) / 2, h - m - gh), Size(gw, gh), style = Stroke(sw))
        drawCircle(line, 2f * u, Offset(w / 2, m + bh * 0.72f))
        drawCircle(line, 2f * u, Offset(w / 2, h - m - bh * 0.72f))

        // Spielerkreise im Corporate-Look: Mint (eigenes Team), Koralle (Gegner)
        val r = 17 * u
        local.forEachIndexed { i, t ->
            val c = Offset(t.x * w, t.y * h)
            val active = i == dragIndex
            val rr = if (active) r * 1.15f else r
            val pl = if (t.playerId >= 0) byId[t.playerId] else null
            val hl = Offset(c.x - rr * 0.3f, c.y - rr * 0.35f)

            // weicher Schatten
            drawCircle(Color.Black.copy(alpha = if (active) 0.38f else 0.26f), rr + 1.5f * u, c + Offset(0f, 2.5f * u))

            val fill: Brush = when {
                t.opponent -> Brush.radialGradient(listOf(Color(0xFFFF9A94), Color(0xFFE5484D)), center = hl, radius = rr * 1.7f)
                pl != null -> Brush.radialGradient(listOf(Color(0xFF9AF5D6), Color(0xFF2FBF8F)), center = hl, radius = rr * 1.7f)
                else -> SolidColor(Color(0xFF5DE4AE).copy(alpha = 0.16f))
            }
            val textColor = when {
                t.opponent -> Color.White
                pl != null -> Color(0xFF062A1D)
                else -> Color(0xFFC9F7E6)
            }
            drawCircle(fill, rr, c)
            if (pl == null && !t.opponent) {
                drawCircle(
                    Color(0xFF5DE4AE).copy(alpha = 0.9f), rr, c,
                    style = Stroke(1.6f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5 * u, 4 * u)))
                )
            } else {
                drawCircle(Color.White.copy(alpha = 0.9f), rr, c, style = Stroke(1.6f * u))
            }

            val label = pl?.number?.toString() ?: t.label
            val layout = measurer.measure(label, labelStyle.copy(color = textColor))
            drawText(layout, topLeft = c - Offset(layout.size.width / 2f, layout.size.height / 2f))

            // Namensschild unter der Figur
            if (pl != null) {
                val nm = measurer.measure(pl.name.substringAfterLast(' ').take(12), nameStyle)
                val pw = nm.size.width + 10 * u
                val ph = nm.size.height + 3 * u
                val x = (c.x - pw / 2).coerceIn(2 * u, (w - pw - 2 * u).coerceAtLeast(2 * u))
                val y = (c.y + rr + 3 * u).coerceAtMost(h - ph - 2 * u)
                drawRoundRect(Color(0xFF0B1826).copy(alpha = 0.8f), Offset(x, y), Size(pw, ph), CornerRadius(ph / 2))
                drawText(nm, topLeft = Offset(x + 5 * u, y + 1.5f * u))
            }
        }
    }
}
