@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.tactics.app.MainViewModel
import de.tactics.app.data.Player

@Composable
fun TeamScreen(vm: MainViewModel, onOpenPlayer: (Long) -> Unit) {
    val players by vm.players.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        if (players.isEmpty()) {
            Text(
                "Noch keine Spieler.\nMit + einen Spieler hinzufügen.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
            items(players, key = { it.id }) { p ->
                val avg = p.averageRating()
                val info = listOfNotNull(
                    p.position.ifBlank { null },
                    avg?.let { "★ " + "%.1f".format(it) }
                ).joinToString("  ·  ")
                ListItem(
                    modifier = Modifier.clickable { onOpenPlayer(p.id) },
                    leadingContent = { Text("${p.number}", style = MaterialTheme.typography.titleLarge) },
                    headlineContent = { Text(p.name) },
                    supportingContent = { Text(if (info.isBlank()) "Profil öffnen" else info) },
                    trailingContent = {
                        IconButton(onClick = { vm.deletePlayer(p) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Löschen")
                        }
                    }
                )
                Divider()
            }
        }
        FloatingActionButton(
            onClick = { creating = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Spieler hinzufügen") }
    }

    if (creating) {
        NewPlayerDialog(
            onDismiss = { creating = false },
            onSave = { vm.savePlayer(it); creating = false }
        )
    }
}

@Composable
private fun NewPlayerDialog(onDismiss: () -> Unit, onSave: (Player) -> Unit) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Spieler hinzufügen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(
                    number, { number = it.filter(Char::isDigit).take(2) },
                    label = { Text("Rückennummer") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(position, { position = it }, label = { Text("Position (z. B. IV, ZM)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onSave(Player(name = name.trim(), number = number.toIntOrNull() ?: 0, position = position.trim())) }
            ) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}
