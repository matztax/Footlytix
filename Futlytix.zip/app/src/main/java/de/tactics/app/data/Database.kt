package de.tactics.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface TacticsDao {
    // Spieler
    @Query("SELECT * FROM players ORDER BY number") fun observePlayers(): Flow<List<Player>>
    @Query("SELECT * FROM players") suspend fun getPlayers(): List<Player>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlayer(p: Player): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlayers(p: List<Player>)
    @Delete suspend fun deletePlayer(p: Player)
    @Query("DELETE FROM players") suspend fun clearPlayers()

    // Aufstellungen
    @Query("SELECT * FROM formations ORDER BY id") fun observeFormations(): Flow<List<Formation>>
    @Query("SELECT * FROM formations") suspend fun getFormations(): List<Formation>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFormation(f: Formation): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFormations(f: List<Formation>)
    @Delete suspend fun deleteFormation(f: Formation)
    @Query("DELETE FROM formations") suspend fun clearFormations()

    // Standards
    @Query("SELECT * FROM set_pieces ORDER BY id") fun observeSetPieces(): Flow<List<SetPiece>>
    @Query("SELECT * FROM set_pieces") suspend fun getSetPieces(): List<SetPiece>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSetPiece(s: SetPiece): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSetPieces(s: List<SetPiece>)
    @Delete suspend fun deleteSetPiece(s: SetPiece)
    @Query("DELETE FROM set_pieces") suspend fun clearSetPieces()

    // Video-Zeichnungen
    @Query("SELECT * FROM video_annotations ORDER BY timestampMs") fun observeAnnotations(): Flow<List<VideoAnnotation>>
    @Query("SELECT * FROM video_annotations") suspend fun getAnnotations(): List<VideoAnnotation>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnnotation(a: VideoAnnotation): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnnotations(a: List<VideoAnnotation>)
    @Delete suspend fun deleteAnnotation(a: VideoAnnotation)
    @Query("DELETE FROM video_annotations") suspend fun clearAnnotations()

    // Video-Bibliothek
    @Query("SELECT * FROM video_items ORDER BY createdAt DESC") fun observeVideos(): Flow<List<VideoItem>>
    @Query("SELECT * FROM video_items") suspend fun getVideos(): List<VideoItem>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertVideo(v: VideoItem): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertVideos(v: List<VideoItem>)
    @Delete suspend fun deleteVideo(v: VideoItem)
    @Query("DELETE FROM video_items") suspend fun clearVideos()
    @Query("SELECT COUNT(*) FROM video_items WHERE uri = :uri") suspend fun countVideosWithUri(uri: String): Int
    @Query("DELETE FROM video_annotations WHERE videoUri = :uri") suspend fun deleteAnnotationsForUri(uri: String)

    // Vereine
    @Query("SELECT * FROM clubs ORDER BY isOwn DESC, name COLLATE NOCASE") fun observeClubs(): Flow<List<Club>>
    @Query("SELECT * FROM clubs") suspend fun getClubs(): List<Club>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertClub(c: Club): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertClubs(c: List<Club>)
    @Delete suspend fun deleteClub(c: Club)
    @Query("DELETE FROM clubs") suspend fun clearClubs()
    @Query("SELECT COUNT(*) FROM clubs WHERE isOwn = 1") suspend fun countOwnClubs(): Int
    @Query("UPDATE players SET clubId = :clubId WHERE id = :id") suspend fun setPlayerClub(id: Long, clubId: Long)
    @Query("UPDATE players SET clubId = :clubId WHERE clubId = 0") suspend fun assignFreePlayers(clubId: Long)
    @Query("UPDATE players SET clubId = 0 WHERE clubId = :clubId") suspend fun detachPlayers(clubId: Long)
    @Query("UPDATE formations SET opponentClubId = 0 WHERE opponentClubId = :clubId") suspend fun clearOpponentRefs(clubId: Long)
    @Query("UPDATE formations SET ownClubId = 0 WHERE ownClubId = :clubId") suspend fun clearOwnRefs(clubId: Long)

    // Transfers
    @Query("SELECT * FROM transfers ORDER BY id DESC") fun observeTransfers(): Flow<List<Transfer>>
    @Query("SELECT * FROM transfers") suspend fun getTransfers(): List<Transfer>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTransfer(t: Transfer): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertTransfers(t: List<Transfer>)
    @Query("DELETE FROM transfers") suspend fun clearTransfers()
    @Query("DELETE FROM transfers WHERE playerId = :playerId") suspend fun deleteTransfersFor(playerId: Long)

    // Attribute (Katalog)
    @Query("SELECT * FROM attribute_defs ORDER BY name COLLATE NOCASE") fun observeAttributeDefs(): Flow<List<AttributeDef>>
    @Query("SELECT * FROM attribute_defs") suspend fun getAttributeDefs(): List<AttributeDef>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttributeDef(a: AttributeDef): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttributeDefs(a: List<AttributeDef>)
    @Delete suspend fun deleteAttributeDef(a: AttributeDef)
    @Query("DELETE FROM attribute_defs") suspend fun clearAttributeDefs()

    // Attribut-Zuordnungen
    @Query("SELECT * FROM attribute_links") fun observeAttributeLinks(): Flow<List<AttributeLink>>
    @Query("SELECT * FROM attribute_links") suspend fun getAttributeLinks(): List<AttributeLink>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttributeLink(l: AttributeLink): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttributeLinks(l: List<AttributeLink>)
    @Delete suspend fun deleteAttributeLink(l: AttributeLink)
    @Query("DELETE FROM attribute_links") suspend fun clearAttributeLinks()
    @Query("DELETE FROM attribute_links WHERE targetType = :type AND targetId = :id") suspend fun deleteLinksFor(type: String, id: Long)
    @Query("DELETE FROM attribute_links WHERE attributeId = :attributeId") suspend fun deleteLinksOfAttribute(attributeId: Long)

    // Analysen
    @Query("SELECT * FROM analyses ORDER BY createdAt DESC") fun observeAnalyses(): Flow<List<Analysis>>
    @Query("SELECT * FROM analyses") suspend fun getAnalyses(): List<Analysis>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnalysis(a: Analysis): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnalyses(a: List<Analysis>)
    @Delete suspend fun deleteAnalysis(a: Analysis)
    @Query("DELETE FROM analyses") suspend fun clearAnalyses()
    @Query("DELETE FROM analyses WHERE targetType = :type AND targetId = :id") suspend fun deleteAnalysesFor(type: String, id: Long)

    // Briefings
    @Query("SELECT * FROM briefings ORDER BY createdAt DESC") fun observeBriefings(): Flow<List<Briefing>>
    @Query("SELECT * FROM briefings") suspend fun getBriefings(): List<Briefing>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBriefing(b: Briefing): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBriefings(b: List<Briefing>)
    @Delete suspend fun deleteBriefing(b: Briefing)
    @Query("DELETE FROM briefings") suspend fun clearBriefings()

    // Übungen
    @Query("SELECT * FROM exercises ORDER BY name COLLATE NOCASE") fun observeExercises(): Flow<List<Exercise>>
    @Query("SELECT * FROM exercises") suspend fun getExercises(): List<Exercise>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertExercise(e: Exercise): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertExercises(e: List<Exercise>)
    @Delete suspend fun deleteExercise(e: Exercise)
    @Query("DELETE FROM exercises") suspend fun clearExercises()

    // Trainingseinheiten
    @Query("SELECT * FROM training_sessions ORDER BY id DESC") fun observeSessions(): Flow<List<TrainingSession>>
    @Query("SELECT * FROM training_sessions") suspend fun getSessions(): List<TrainingSession>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSession(s: TrainingSession): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSessions(s: List<TrainingSession>)
    @Delete suspend fun deleteSession(s: TrainingSession)
    @Query("DELETE FROM training_sessions") suspend fun clearSessions()
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `video_items` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`name` TEXT NOT NULL, `uri` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
        )
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `players` ADD COLUMN `clubId` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `formations` ADD COLUMN `ownClubId` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `formations` ADD COLUMN `opponentClubId` INTEGER NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `clubs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`name` TEXT NOT NULL, `isOwn` INTEGER NOT NULL, `system` TEXT NOT NULL, `notes` TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `transfers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`playerId` INTEGER NOT NULL, `fromClubId` INTEGER NOT NULL, `toClubId` INTEGER NOT NULL, " +
                "`date` TEXT NOT NULL, `note` TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `attribute_defs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`name` TEXT NOT NULL, `positive` INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `attribute_links` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`targetType` TEXT NOT NULL, `targetId` INTEGER NOT NULL, `attributeId` INTEGER NOT NULL, " +
                "`level` INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `analyses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`targetType` TEXT NOT NULL, `targetId` INTEGER NOT NULL, `title` TEXT NOT NULL, " +
                "`text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
        )
        // Bisherige Spieler gehören zum Standard-Verein "Mein Team"
        db.execSQL("INSERT INTO `clubs` (`name`, `isOwn`, `system`, `notes`) VALUES ('Mein Team', 1, '', '')")
        db.execSQL("UPDATE `players` SET `clubId` = (SELECT `id` FROM `clubs` WHERE `isOwn` = 1 LIMIT 1)")
    }
}

@Database(
    entities = [
        Player::class, Formation::class, SetPiece::class, VideoAnnotation::class,
        Briefing::class, Exercise::class, TrainingSession::class, VideoItem::class,
        Club::class, Transfer::class, AttributeDef::class, AttributeLink::class, Analysis::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): TacticsDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tactics.db"
                ).addMigrations(MIGRATION_2_3, MIGRATION_3_4).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
