package de.tactics.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface TacticsDao {
    // Spieler
    @Query("SELECT * FROM players ORDER BY number") fun observePlayers(): Flow<List<Player>>
    @Query("SELECT * FROM players") suspend fun getPlayers(): List<Player>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlayer(p: Player): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPlayers(p: List<Player>)
    @Delete suspend fun deletePlayer(p: Player)
    @Query("DELETE FROM players") suspend fun clearPlayers()

    // Aufstellungen
    @Query("SELECT * FROM formations ORDER BY id") fun observeFormations(): Flow<List<Formation>>
    @Query("SELECT * FROM formations") suspend fun getFormations(): List<Formation>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFormation(f: Formation): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFormations(f: List<Formation>)
    @Delete suspend fun deleteFormation(f: Formation)
    @Query("DELETE FROM formations") suspend fun clearFormations()

    // Standards
    @Query("SELECT * FROM set_pieces ORDER BY id") fun observeSetPieces(): Flow<List<SetPiece>>
    @Query("SELECT * FROM set_pieces") suspend fun getSetPieces(): List<SetPiece>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSetPiece(s: SetPiece): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSetPieces(s: List<SetPiece>)
    @Delete suspend fun deleteSetPiece(s: SetPiece)
    @Query("DELETE FROM set_pieces") suspend fun clearSetPieces()

    // Video-Zeichnungen
    @Query("SELECT * FROM video_annotations ORDER BY timestampMs") fun observeAnnotations(): Flow<List<VideoAnnotation>>
    @Query("SELECT * FROM video_annotations") suspend fun getAnnotations(): List<VideoAnnotation>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnnotation(a: VideoAnnotation): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnnotations(a: List<VideoAnnotation>)
    @Delete suspend fun deleteAnnotation(a: VideoAnnotation)
    @Query("DELETE FROM video_annotations") suspend fun clearAnnotations()

    // Briefings
    @Query("SELECT * FROM briefings ORDER BY createdAt DESC") fun observeBriefings(): Flow<List<Briefing>>
    @Query("SELECT * FROM briefings") suspend fun getBriefings(): List<Briefing>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBriefing(b: Briefing): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBriefings(b: List<Briefing>)
    @Delete suspend fun deleteBriefing(b: Briefing)
    @Query("DELETE FROM briefings") suspend fun clearBriefings()

    // Übungen
    @Query("SELECT * FROM exercises ORDER BY name COLLATE NOCASE") fun observeExercises(): Flow<List<Exercise>>
    @Query("SELECT * FROM exercises") suspend fun getExercises(): List<Exercise>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertExercise(e: Exercise): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertExercises(e: List<Exercise>)
    @Delete suspend fun deleteExercise(e: Exercise)
    @Query("DELETE FROM exercises") suspend fun clearExercises()

    // Trainingseinheiten
    @Query("SELECT * FROM training_sessions ORDER BY id DESC") fun observeSessions(): Flow<List<TrainingSession>>
    @Query("SELECT * FROM training_sessions") suspend fun getSessions(): List<TrainingSession>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSession(s: TrainingSession): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSessions(s: List<TrainingSession>)
    @Delete suspend fun deleteSession(s: TrainingSession)
    @Query("DELETE FROM training_sessions") suspend fun clearSessions()
}

@Database(
    entities = [
        Player::class, Formation::class, SetPiece::class, VideoAnnotation::class,
        Briefing::class, Exercise::class, TrainingSession::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): TacticsDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tactics.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
