package de.tactics.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import de.tactics.app.ui.TacticsApp
import de.tactics.app.ui.TacticsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TacticsTheme {
                TacticsApp()
            }
        }
    }
}
