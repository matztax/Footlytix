@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import de.tactics.app.MainViewModel
import de.tactics.app.data.Scribble
import de.tactics.app.data.VideoAnnotation
import de.tactics.app.data.VideoItem
import de.tactics.app.data.decodeScribbles
import de.tactics.app.data.encodeScribbles

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

private fun displayName(ctx: Context, uri: Uri): String {
    val name = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
    return name?.substringBeforeLast('.')?.ifBlank { null } ?: "Neues Video"
}

/** Bibliothek: mehrere Videos, jeweils mit eigenem Namen. */
@Composable
fun VideoListScreen(vm: MainViewModel, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val videos by vm.videos.collectAsStateWithLifecycle()
    val annotations by vm.annotations.collectAsStateWithLifecycle()
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var renaming by remember { mutableStateOf<VideoItem?>(null) }
    var deleting by remember { mutableStateOf<VideoItem?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pendingUri = uri
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (videos.isEmpty()) {
            Text(
                "Noch keine Videos.\nMit + ein Video vom Gerät hinzufügen und benennen. Die Datei bleibt auf dem Gerät, die App speichert nur den Verweis.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
            items(videos, key = { it.id }) { v ->
                val scenes = annotations.count { it.videoUri == v.uri }
                val date = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY)
                    .format(java.util.Date(v.createdAt))
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clickable { onOpen(v.id) }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(v.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "$scenes Szenen · hinzugefügt am $date",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { renaming = v }) { Text("Umbenennen") }
                            TextButton(onClick = { deleting = v }) { Text("Löschen") }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { picker.launch(arrayOf("video/*")) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Video hinzufügen") }
    }

    pendingUri?.let { uri ->
        NameDialog(
            title = "Video benennen",
            initial = displayName(ctx, uri),
            onDismiss = { pendingUri = null },
            onSave = { name ->
                vm.saveVideo(VideoItem(name = name, uri = uri.toString()))
                pendingUri = null
            }
        )
    }
    renaming?.let { v ->
        NameDialog(
            title = "Video umbenennen",
            initial = v.name,
            onDismiss = { renaming = null },
            onSave = { name -> vm.saveVideo(v.copy(name = name)); renaming = null }
        )
    }
    deleting?.let { v ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Video entfernen?") },
            text = { Text("„${v.name}“ wird aus der Liste entfernt, ebenso die gespeicherten Szenen dazu. Die Videodatei auf dem Gerät bleibt erhalten.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteVideo(v); deleting = null }) { Text("Entfernen") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Abbrechen") } }
        )
    }
}

/** Ein einzelnes Video abspielen und Szenen mit Zeichnungen markieren. */
@Composable
fun VideoPlayerScreen(vm: MainViewModel, videoId: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val videos by vm.videos.collectAsStateWithLifecycle()
    val annotations by vm.annotations.collectAsStateWithLifecycle()
    val video = videos.firstOrNull { it.id == videoId }
    val uri = video?.uri

    var drawMode by remember { mutableStateOf(false) }
    var scribbles by remember { mutableStateOf<List<Scribble>>(emptyList()) }
    var stamp by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf(false) }

    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    LaunchedEffect(uri) {
        if (uri != null) {
            exo.setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
            exo.prepare()
        }
    }

    if (video == null || uri == null) {
        Column(Modifier.padding(16.dp)) {
            TextButton(onClick = onBack) { Text("← Zurück") }
            Text("Video nicht gefunden.")
        }
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Zurück") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { renaming = true }) { Text("Umbenennen") }
        }
        Text(video.name, style = MaterialTheme.typography.titleLarge)

        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { this.player = exo } },
                modifier = Modifier.fillMaxSize()
            )
            if (drawMode || scribbles.isNotEmpty()) {
                DrawingOverlay(
                    scribbles = scribbles,
                    enabled = drawMode,
                    onFinished = { scribbles = scribbles + it },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Text(
            "Pausiere an einer Stelle, tippe auf „Zeichnen“ und male Laufwege oder Räume ins Bild.",
            style = MaterialTheme.typography.bodySmall
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!drawMode) {
                Button(onClick = { exo.pause(); stamp = exo.currentPosition; drawMode = true }) { Text("Zeichnen") }
            } else {
                Button(onClick = { drawMode = false }) { Text("Fertig") }
            }
            OutlinedButton(
                enabled = scribbles.isNotEmpty(),
                onClick = { scribbles = scribbles.dropLast(1) }
            ) { Text("Zurück") }
            OutlinedButton(onClick = { scribbles = emptyList(); drawMode = false }) { Text("Ausblenden") }
        }

        if (scribbles.isNotEmpty()) {
            OutlinedTextField(
                note, { note = it },
                label = { Text("Notiz zur Szene") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                vm.saveAnnotation(
                    VideoAnnotation(
                        videoUri = uri,
                        timestampMs = stamp,
                        scribblesJson = encodeScribbles(scribbles),
                        note = note.trim()
                    )
                )
                note = ""
                scribbles = emptyList()
                drawMode = false
            }) { Text("Zeichnung bei ${fmt(stamp)} speichern") }
        }

        val mine = annotations.filter { it.videoUri == uri }
        if (mine.isNotEmpty()) {
            Text("Gespeicherte Szenen", style = MaterialTheme.typography.titleMedium)
            mine.forEach { a ->
                Card(
                    Modifier.fillMaxWidth().clickable {
                        exo.pause()
                        exo.seekTo(a.timestampMs)
                        stamp = a.timestampMs
                        scribbles = decodeScribbles(a.scribblesJson)
                        drawMode = false
                    }
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(fmt(a.timestampMs), style = MaterialTheme.typography.titleSmall)
                            if (a.note.isNotBlank()) Text(a.note)
                        }
                        IconButton(onClick = { vm.deleteAnnotation(a) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Löschen")
                        }
                    }
                }
            }
        }
    }

    if (renaming) {
        NameDialog(
            title = "Video umbenennen",
            initial = video.name,
            onDismiss = { renaming = false },
            onSave = { name -> vm.saveVideo(video.copy(name = name)); renaming = false }
        )
    }
}

/** Zeichenfläche über dem Video; Striche sind normiert (0..1) und damit größenunabhängig. */
@Composable
fun DrawingOverlay(
    scribbles: List<Scribble>,
    enabled: Boolean,
    onFinished: (Scribble) -> Unit,
    modifier: Modifier = Modifier
) {
    var current by remember { mutableStateOf<List<Float>>(emptyList()) }
    val finished by rememberUpdatedState(onFinished)

    val gesture = if (enabled) {
        Modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> current = listOf(o.x / size.width, o.y / size.height) },
                onDrag = { change, _ ->
                    change.consume()
                    val p = change.position
                    current = current + listOf(p.x / size.width, p.y / size.height)
                },
                onDragEnd = {
                    if (current.size >= 4) finished(Scribble(current))
                    current = emptyList()
                },
                onDragCancel = { current = emptyList() }
            )
        }
    } else Modifier

    Canvas(modifier.then(gesture)) {
        fun drawPoints(pts: List<Float>) {
            var i = 0
            while (i + 3 < pts.size) {
                drawLine(
                    color = Color(0xFFFFEB3B),
                    start = Offset(pts[i] * size.width, pts[i + 1] * size.height),
                    end = Offset(pts[i + 2] * size.width, pts[i + 3] * size.height),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
                i += 2
            }
        }
        scribbles.forEach { drawPoints(it.points) }
        drawPoints(current)
    }
}
