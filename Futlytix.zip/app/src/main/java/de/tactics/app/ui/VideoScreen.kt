@file:OptIn(ExperimentalMaterial3Api::class)

package de.tactics.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import de.tactics.app.MainViewModel
import de.tactics.app.data.Scribble
import de.tactics.app.data.VideoAnnotation
import de.tactics.app.data.decodeScribbles
import de.tactics.app.data.encodeScribbles

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun VideoScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val annotations by vm.annotations.collectAsStateWithLifecycle()
    var videoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var drawMode by remember { mutableStateOf(false) }
    var scribbles by remember { mutableStateOf<List<Scribble>>(emptyList()) }
    var stamp by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf("") }

    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    LaunchedEffect(videoUri) {
        videoUri?.let {
            exo.setMediaItem(MediaItem.fromUri(Uri.parse(it)))
            exo.prepare()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            videoUri = uri.toString()
            scribbles = emptyList()
            drawMode = false
        }
    }

    val uri = videoUri
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(onClick = { picker.launch(arrayOf("video/*")) }) {
            Text(if (uri == null) "Video wählen" else "Anderes Video wählen")
        }

        if (uri == null) {
            Text("Wähle ein Video vom Gerät (z. B. Spielaufnahme). Es bleibt lokal, nur der Verweis wird gespeichert. Pausiere an einer Stelle, tippe auf „Zeichnen“ und male Laufwege oder Räume ins Bild.")
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { this.player = exo } },
                    modifier = Modifier.fillMaxSize()
                )
                if (drawMode || scribbles.isNotEmpty()) {
                    DrawingOverlay(
                        scribbles = scribbles,
                        enabled = drawMode,
                        onFinished = { scribbles = scribbles + it },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!drawMode) {
                    Button(onClick = { exo.pause(); stamp = exo.currentPosition; drawMode = true }) { Text("Zeichnen") }
                } else {
                    Button(onClick = { drawMode = false }) { Text("Fertig") }
                }
                OutlinedButton(
                    enabled = scribbles.isNotEmpty(),
                    onClick = { scribbles = scribbles.dropLast(1) }
                ) { Text("Zurück") }
                OutlinedButton(onClick = { scribbles = emptyList(); drawMode = false }) { Text("Ausblenden") }
            }

            if (scribbles.isNotEmpty()) {
                OutlinedTextField(
                    note, { note = it },
                    label = { Text("Notiz zur Szene") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    vm.saveAnnotation(
                        VideoAnnotation(
                            videoUri = uri,
                            timestampMs = stamp,
                            scribblesJson = encodeScribbles(scribbles),
                            note = note.trim()
                        )
                    )
                    note = ""
                    scribbles = emptyList()
                    drawMode = false
                }) { Text("Zeichnung bei ${fmt(stamp)} speichern") }
            }

            val mine = annotations.filter { it.videoUri == uri }
            if (mine.isNotEmpty()) {
                Text("Gespeicherte Szenen", style = MaterialTheme.typography.titleMedium)
                mine.forEach { a ->
                    Card(
                        Modifier.fillMaxWidth().clickable {
                            exo.pause()
                            exo.seekTo(a.timestampMs)
                            stamp = a.timestampMs
                            scribbles = decodeScribbles(a.scribblesJson)
                            drawMode = false
                        }
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(fmt(a.timestampMs), style = MaterialTheme.typography.titleSmall)
                                if (a.note.isNotBlank()) Text(a.note)
                            }
                            IconButton(onClick = { vm.deleteAnnotation(a) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Löschen")
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Zeichenfläche über dem Video; Striche sind normiert (0..1) und damit größenunabhängig. */
@Composable
fun DrawingOverlay(
    scribbles: List<Scribble>,
    enabled: Boolean,
    onFinished: (Scribble) -> Unit,
    modifier: Modifier = Modifier
) {
    var current by remember { mutableStateOf<List<Float>>(emptyList()) }
    val finished by rememberUpdatedState(onFinished)

    val gesture = if (enabled) {
        Modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> current = listOf(o.x / size.width, o.y / size.height) },
                onDrag = { change, _ ->
                    change.consume()
                    val p = change.position
                    current = current + listOf(p.x / size.width, p.y / size.height)
                },
                onDragEnd = {
                    if (current.size >= 4) finished(Scribble(current))
                    current = emptyList()
                },
                onDragCancel = { current = emptyList() }
            )
        }
    } else Modifier

    Canvas(modifier.then(gesture)) {
        fun drawPoints(pts: List<Float>) {
            var i = 0
            while (i + 3 < pts.size) {
                drawLine(
                    color = Color(0xFFFFEB3B),
                    start = Offset(pts[i] * size.width, pts[i + 1] * size.height),
                    end = Offset(pts[i + 2] * size.width, pts[i + 3] * size.height),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
                i += 2
            }
        }
        scribbles.forEach { drawPoints(it.points) }
        drawPoints(current)
    }
}
