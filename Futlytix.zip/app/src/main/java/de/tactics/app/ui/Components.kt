package de.tactics.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Bewertung mit 1..5 Sternen; erneutes Tippen auf den gleichen Stern setzt auf "nicht bewertet". */
@Composable
fun RatingRow(label: String, value: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        for (i in 1..5) {
            Icon(
                Icons.Default.Star,
                contentDescription = "$i Sterne",
                tint = if (i <= value) Color(0xFFFFC107) else Color(0x44FFFFFF),
                modifier = Modifier
                    .size(34.dp)
                    .clickable { onChange(if (value == i) 0 else i) }
            )
        }
    }
}
