# Futlytix (lokal, ohne Server)

Native Android-App (Kotlin, Jetpack Compose) für Amateurfußball-Teams. Alle Daten bleiben auf dem Gerät.

## Tabs
- **Spiele**: Saisons, Spiele mit Datum, Gegner, Ergebnis, Aufstellung und Einsätzen (Minuten, Tore, Vorlagen, Karten, Verletzung), Saisonstatistik pro Spieler und Team
- **Datenbank**: Spieler (nach Verein filterbar), Vereine (eigene und Gegner mit System, Notizen, Attributen und Analysen) und der Attribut-Katalog (frei positive/negative Attribute). Spielerprofil mit Stärken, Schwächen, Ziele, Notizen, Sternebewertung, Attributen, Analysen und Transfer zwischen Vereinen (alle Daten bleiben erhalten)
- **Taktik**: Aufstellung (eigenes Team und Gegner aus der Datenbank wählen, Spieler beider Seiten per Tippen zuweisen, Gegner-Info mit Analysen als Briefing speichern, mehrere Phasen) und Standards (Rollenzuweisung)
- **Training** (inkl. Anwesenheit je Einheit und PDF-Export mit Übungsskizzen): Einheiten planen (Datum, Ziel, Ablauf, Minuten, Materialbedarf, Teilen) und Übungen bauen (Aufbau mit Hütchen, Stangen, Mauer, Koordinationsleiter, Hürden, Toren, Bällen; Laufwege zeichnen)
- **Video**: Bibliothek mit mehreren benennbaren Videos; Zeichnungen an Zeitmarken; Marker (Pass, Tor, Ballverlust ...) mit Person und optionaler Cliplänge; Clip-Übersicht nach Art, Verein und Person
- **Briefing**: Texte für Spieler, Weitergabe über den Teilen-Dialog
- Menü (⋮): Backup als JSON exportieren/importieren

## Architektur
Room (SQLite, Version 6, Migrationen 2→3 bis 5→6 vorhanden) als einzige Datenquelle, ein `MainViewModel`, Navigation Compose. Kein Firebase, kein Netzwerk, keine Berechtigungen.

## Bauen
- Android Studio: Projekt öffnen, Run, oder `gradle assembleDebug`
- Ohne Rechner: ZIP in ein GitHub-Repo laden, `.github/workflows/*.yml` im Repo-Root anlegen, unter "Actions" die APK als Artifact laden. Die neueste ZIP (nach Upload-Zeit) wird gebaut.
- Die Debug-APK ist mit dem mitgelieferten `app/debug.keystore` signiert, dadurch lassen sich Updates ohne Deinstallation installieren (nur ab dieser Version).

## Google Play
- Ziel-API 36, Paketname `de.futlytix.app`, Edge-to-Edge aktiv.
- Der Cloud-Build erzeugt zusätzlich ein signiertes App Bundle (`app-release.aab`), wenn die Secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` und `KEY_PASSWORD` gesetzt sind.
- `versionCode` entspricht der GitHub-Laufnummer, damit jeder Upload höher ist als der vorige.
- Die benötigte Gradle-Version steht in `.gradle-version`.

## Hinweis zur Datenbank
Version 1 -> 2 setzt die Datenbank zurück (Entwicklungsphase). Vor dem Update ggf. ein Backup exportieren (wird nur teilweise importierbar sein, da neue Felder hinzukamen).

## Neu in 1.5
- Spiele und Saisonstatistik, Verfügbarkeit (verletzt, gesperrt, Urlaub ...), Trainingsanwesenheit
- Bewertungsverlauf mit Netzdiagramm und Trend je Spieler
- Pfeile für Laufwege auf dem Taktikfeld, Standards mit Spielfelddiagramm, Querformat und Tabletlayout
- PDF- und Bild-Export (Aufstellung, Übung, Trainingseinheit, Briefing)
- Video-Marker und Clips (nicht destruktiv: Start und Ende werden abgespielt, die Datei wird nicht zugeschnitten)
- App-Sperre (Fingerabdruck/Gesicht/Geräte-PIN) und tägliches Auto-Backup mit optionalem Ordner

## Neu in 1.6
- Spieltag-Modus: Uhr, Tasten für Tor, Gegentor, Karten, Wechsel und Verletzung; beim Beenden werden Ergebnis, Minuten, Tore, Vorlagen und Karten automatisch berechnet
- Import: Spielerliste (CSV) und Spielplan (.ics) aus SpielerPlus, Verbandsportalen oder Tabellen
- Schutz vor Datenverlust: Rückfrage bei ungespeicherten Änderungen und vor dem Löschen; alte Exporte werden nach einem Tag entfernt
