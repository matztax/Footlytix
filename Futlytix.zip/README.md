# Futlytix (lokal, ohne Server)

Native Android-App (Kotlin, Jetpack Compose) für Amateurfußball-Teams. Alle Daten bleiben auf dem Gerät.

## Tabs
- **Kader**: Spieler anlegen; Tippen öffnet das Trainerprofil (Stärken, Schwächen, Ziele, Notizen, Bewertung in Technik/Taktik/Athletik/Mentalität)
- **Taktik**: Aufstellung (Spieler aus dem Kader per Tippen zuweisen, Bank-Anzeige, mehrere Phasen, Gegnersystem) und Standards (Rollenzuweisung)
- **Training**: Einheiten planen (Datum, Ziel, Ablauf, Minuten, Materialbedarf, Teilen) und Übungen bauen (Aufbau mit Hütchen, Stangen, Mauer, Koordinationsleiter, Hürden, Toren, Bällen; Laufwege zeichnen)
- **Video**: lokales Video mit Zeichnungen an Zeitmarken
- **Briefing**: Texte für Spieler, Weitergabe über den Teilen-Dialog
- Menü (⋮): Backup als JSON exportieren/importieren

## Architektur
Room (SQLite, Version 2) als einzige Datenquelle, ein `MainViewModel`, Navigation Compose. Kein Firebase, kein Netzwerk, keine Berechtigungen.

## Bauen
- Android Studio: Projekt öffnen, Run, oder `gradle assembleDebug`
- Ohne Rechner: ZIP in ein GitHub-Repo laden, `.github/workflows/*.yml` im Repo-Root anlegen, unter "Actions" die APK als Artifact laden. Die neueste ZIP (nach Upload-Zeit) wird gebaut.
- Die Debug-APK ist mit dem mitgelieferten `app/debug.keystore` signiert, dadurch lassen sich Updates ohne Deinstallation installieren (nur ab dieser Version).

## Hinweis zur Datenbank
Version 1 -> 2 setzt die Datenbank zurück (Entwicklungsphase). Vor dem Update ggf. ein Backup exportieren (wird nur teilweise importierbar sein, da neue Felder hinzukamen).
