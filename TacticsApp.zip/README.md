# Taktik-App (lokal, ohne Server)

Native Android-App (Kotlin, Jetpack Compose) für Amateurfußball-Teams. Alle Daten bleiben auf dem Gerät.

## Module
- **Kader**: Spieler mit Nummer und Position (Room)
- **Taktik**: Aufstellungen mit Drag & Drop, mehrere Phasen, gegnerisches System
- **Standards**: Ecken/Freistöße/Einwürfe mit Rollenzuweisung
- **Video**: lokales Video (Storage Access Framework) mit Zeichnungen an Zeitmarken (Media3/ExoPlayer)
- **Briefing**: Texte für Spieler, Weitergabe per Teilen-Dialog (WhatsApp, Mail ...)
- **Backup**: Menü (⋮) → Export/Import als JSON-Datei

## Architektur
Room (SQLite) als einzige Datenquelle, ein `MainViewModel`, Navigation Compose. Kein Firebase, kein Netzwerk, keine Berechtigungen.

## Bauen
- Android Studio: Projekt öffnen, Run, oder `gradle assembleDebug`
- Ohne Rechner: ZIP in ein GitHub-Repo laden, `.github/workflows/build.yml` im Repo-Root anlegen, unter „Actions“ die APK als Artifact laden.

## Grenzen
- Kein automatischer Lesestatus bei Briefings (dafür wäre ein Server nötig)
- Video-Verweise im Backup gelten nur auf dem Gerät mit dem Originalvideo
