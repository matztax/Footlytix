package de.tactics.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import de.tactics.app.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val dao = db.dao()

    private fun <T> Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val players = dao.observePlayers().state(emptyList())
    val formations = dao.observeFormations().state(emptyList())
    val setPieces = dao.observeSetPieces().state(emptyList())
    val annotations = dao.observeAnnotations().state(emptyList())
    val briefings = dao.observeBriefings().state(emptyList())

    // Kader
    fun savePlayer(p: Player) { viewModelScope.launch { dao.upsertPlayer(p) } }
    fun deletePlayer(p: Player) { viewModelScope.launch { dao.deletePlayer(p) } }

    // Aufstellungen
    fun createFormation(name: String, ownSystem: String, opponentSystem: String, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val tokens = buildTokens(ownSystem, false) + buildTokens(opponentSystem, true)
            val phases = listOf(Phase("Phase 1", tokens))
            val id = dao.upsertFormation(Formation(name = name, phasesJson = encodePhases(phases)))
            onCreated(id)
        }
    }
    fun saveFormation(f: Formation) { viewModelScope.launch { dao.upsertFormation(f) } }
    fun deleteFormation(f: Formation) { viewModelScope.launch { dao.deleteFormation(f) } }

    // Standards
    fun saveSetPiece(s: SetPiece) { viewModelScope.launch { dao.upsertSetPiece(s) } }
    fun deleteSetPiece(s: SetPiece) { viewModelScope.launch { dao.deleteSetPiece(s) } }

    // Video-Zeichnungen
    fun saveAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.upsertAnnotation(a) } }
    fun deleteAnnotation(a: VideoAnnotation) { viewModelScope.launch { dao.deleteAnnotation(a) } }

    // Briefings
    fun saveBriefing(b: Briefing) { viewModelScope.launch { dao.upsertBriefing(b) } }
    fun deleteBriefing(b: Briefing) { viewModelScope.launch { dao.deleteBriefing(b) } }

    // Backup
    suspend fun exportJson(): String = AppJson.encodeToString(
        BackupBundle(
            players = dao.getPlayers(),
            formations = dao.getFormations(),
            setPieces = dao.getSetPieces(),
            annotations = dao.getAnnotations(),
            briefings = dao.getBriefings()
        )
    )

    suspend fun importJson(text: String) {
        val b = AppJson.decodeFromString<BackupBundle>(text)
        db.withTransaction {
            dao.clearPlayers(); dao.clearFormations(); dao.clearSetPieces()
            dao.clearAnnotations(); dao.clearBriefings()
            dao.upsertPlayers(b.players)
            dao.upsertFormations(b.formations)
            dao.upsertSetPieces(b.setPieces)
            dao.upsertAnnotations(b.annotations)
            dao.upsertBriefings(b.briefings)
        }
    }
}
