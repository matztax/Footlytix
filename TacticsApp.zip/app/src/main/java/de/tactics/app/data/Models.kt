package de.tactics.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
}

@Serializable
@Entity(tableName = "players")
data class Player(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val number: Int = 0,
    val position: String = ""
)

/** Spielfigur auf dem Taktikfeld. x/y sind normiert (0..1). */
@Serializable
data class Token(val label: String, val x: Float, val y: Float, val opponent: Boolean = false)

/** Eine Phase einer Aufstellung (z. B. Grundordnung, Umschalten, Gegner wechselt System). */
@Serializable
data class Phase(val name: String, val tokens: List<Token>)

@Serializable
@Entity(tableName = "formations")
data class Formation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phasesJson: String
)

@Serializable
data class RoleAssignment(val role: String, val player: String)

@Serializable
@Entity(tableName = "set_pieces")
data class SetPiece(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val rolesJson: String,
    val notes: String = ""
)

/** Ein Strich der Zeichnung; points = x1,y1,x2,y2,... (normiert 0..1). */
@Serializable
data class Scribble(val points: List<Float>)

@Serializable
@Entity(tableName = "video_annotations")
data class VideoAnnotation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoUri: String,
    val timestampMs: Long,
    val scribblesJson: String,
    val note: String = ""
)

@Serializable
@Entity(tableName = "briefings")
data class Briefing(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class BackupBundle(
    val version: Int = 1,
    val players: List<Player> = emptyList(),
    val formations: List<Formation> = emptyList(),
    val setPieces: List<SetPiece> = emptyList(),
    val annotations: List<VideoAnnotation> = emptyList(),
    val briefings: List<Briefing> = emptyList()
)

// ---------- JSON-Helfer ----------
fun decodePhases(json: String): List<Phase> =
    runCatching { AppJson.decodeFromString<List<Phase>>(json) }.getOrDefault(emptyList())

fun encodePhases(phases: List<Phase>): String = AppJson.encodeToString(phases)

fun decodeRoles(json: String): List<RoleAssignment> =
    runCatching { AppJson.decodeFromString<List<RoleAssignment>>(json) }.getOrDefault(emptyList())

fun encodeRoles(roles: List<RoleAssignment>): String = AppJson.encodeToString(roles)

fun decodeScribbles(json: String): List<Scribble> =
    runCatching { AppJson.decodeFromString<List<Scribble>>(json) }.getOrDefault(emptyList())

fun encodeScribbles(s: List<Scribble>): String = AppJson.encodeToString(s)

// ---------- Aufstellungen erzeugen ----------
/** "4-2-3-1" -> [4,2,3,1]; bei ungültiger Eingabe 4-4-2. */
fun parseSystem(s: String): List<Int> {
    val parts = s.split('-', ' ', ',').mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..6 }
    return if (parts.isNotEmpty() && parts.sum() == 10) parts else listOf(4, 4, 2)
}

fun buildTokens(system: String, opponent: Boolean): List<Token> {
    val rows = listOf(1) + parseSystem(system)
    val tokens = mutableListOf<Token>()
    var n = 1
    rows.forEachIndexed { r, count ->
        val own = 0.93f - r * (0.43f / (rows.size - 1))
        val y = if (opponent) 1f - own else own
        for (k in 0 until count) {
            tokens += Token(label = n.toString(), x = (k + 1f) / (count + 1f), y = y, opponent = opponent)
            n++
        }
    }
    return tokens
}
