package com.taktikapp

import android.app.Application
import androidx.work.*
import com.taktikapp.data.repository.SyncWorker
import java.util.concurrent.TimeUnit

class TaktikApp : Application() {

    override fun onCreate() {
        super.onCreate()
        scheduleBackgroundSync()
    }

    private fun scheduleBackgroundSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "taktikapp_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
