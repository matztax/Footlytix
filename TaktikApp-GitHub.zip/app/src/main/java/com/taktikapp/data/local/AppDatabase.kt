package com.taktikapp.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.taktikapp.data.local.dao.*
import com.taktikapp.data.local.entity.*

@Database(
    entities = [
        TeamEntity::class,
        PlayerEntity::class,
        FormationEntity::class,
        SetPieceEntity::class,
        VideoAnnotationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun teamDao(): TeamDao
    abstract fun playerDao(): PlayerDao
    abstract fun formationDao(): FormationDao
    abstract fun setPieceDao(): SetPieceDao
    abstract fun videoAnnotationDao(): VideoAnnotationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "taktikapp.db"
                ).build().also { INSTANCE = it }
            }
    }
}
