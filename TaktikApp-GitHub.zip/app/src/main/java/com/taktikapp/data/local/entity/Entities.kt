package com.taktikapp.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Wir speichern die komplexeren, verschachtelten Felder (Positionen, Strokes, Zuweisungen)
 * als JSON-String in der lokalen DB. Das hält das Schema simpel und robust gegenüber
 * Modelländerungen, während Firestore ohnehin dokumentenbasiert (JSON-artig) arbeitet -
 * so bleibt die lokale Struktur nah an der Cloud-Struktur, was Sync-Konflikte reduziert.
 */

@Entity(tableName = "teams")
data class TeamEntity(
    @PrimaryKey val id: String,
    val name: String,
    val coachUserId: String,
    val needsSync: Boolean = false,
    val lastModified: Long = System.currentTimeMillis()
)

@Entity(tableName = "players")
data class PlayerEntity(
    @PrimaryKey val id: String,
    val teamId: String,
    val name: String,
    val shirtNumber: Int,
    val preferredPosition: String,
    val deviceToken: String?,
    val isInjured: Boolean,
    val needsSync: Boolean = false
)

@Entity(tableName = "formations")
data class FormationEntity(
    @PrimaryKey val id: String,
    val teamId: String,
    val title: String,
    val systemLabel: String,
    val opponentSystemLabel: String?,
    val phasesJson: String, // JSON-Liste von FormationPhase
    val updatedAt: Long,
    val needsSync: Boolean = false
)

@Entity(tableName = "set_pieces")
data class SetPieceEntity(
    @PrimaryKey val id: String,
    val teamId: String,
    val name: String,
    val type: String,
    val assignmentsJson: String, // JSON-Liste von SetPieceAssignment
    val notes: String,
    val linkedVideoAnnotationId: String?,
    val needsSync: Boolean = false
)

@Entity(tableName = "video_annotations")
data class VideoAnnotationEntity(
    @PrimaryKey val id: String,
    val teamId: String,
    val videoUrl: String,
    val localFilePath: String?, // für Offline-Videos, die noch nicht hochgeladen sind
    val title: String,
    val eventTagJson: String?,
    val strokesJson: String, // JSON-Liste von DrawingStroke
    val createdAt: Long,
    val needsSync: Boolean = false
)

object JsonUtil {
    val json = Json { ignoreUnknownKeys = true }
}
