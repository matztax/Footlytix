package com.taktikapp.data.model

import kotlinx.serialization.Serializable

/**
 * Koordinaten sind normalisiert (0.0 - 1.0) relativ zur Spielfeldgröße,
 * damit die Darstellung auf jedem Gerät (Handy, Tablet, Smartboard) skaliert.
 */
@Serializable
data class PitchPosition(
    val x: Float,
    val y: Float
)

/**
 * Eine einzelne "Phase" einer Formation, z.B. Grundordnung, oder die Verschiebung
 * als Reaktion auf einen gegnerischen Systemwechsel (4-2-3-1 -> 3-5-2).
 */
@Serializable
data class FormationPhase(
    val id: String = "",
    val label: String = "Grundordnung", // z.B. "Pressing-Trigger: Rückpass zum Torwart"
    val playerPositions: Map<String, PitchPosition> = emptyMap(), // playerId -> Position
    val notes: String = ""
)

@Serializable
data class Formation(
    val id: String = "",
    val teamId: String = "",
    val title: String = "",
    val systemLabel: String = "4-3-3", // z.B. 4-2-3-1
    val opponentSystemLabel: String? = null, // für Szenarioplanung gegen bestimmtes System
    val phases: List<FormationPhase> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
