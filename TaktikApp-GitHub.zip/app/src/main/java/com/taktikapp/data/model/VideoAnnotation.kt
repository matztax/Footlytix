package com.taktikapp.data.model

import kotlinx.serialization.Serializable

enum class DrawingTool { LINE, ARROW, CIRCLE, RECTANGLE, FREEHAND, PLAYER_MARKER, ZONE }

/**
 * Ein einzelner Zeichen-Stroke. Punkte sind normalisiert (0..1) relativ zur Videobild-Fläche.
 * showFromMs/showUntilMs steuert, in welchem Zeitfenster die Zeichnung sichtbar ist.
 *
 * WICHTIG (bewusste Grenze des Grundgerüsts):
 * Diese Zeichnung ist an feste Bildkoordinaten gebunden, NICHT an einen sich bewegenden Spieler
 * (kein automatisches Objekt-Tracking/Player-Tracking). Für Amateurvideomaterial ohne
 * synchronisierte Multi-Kamera-Systeme ist zuverlässiges Auto-Tracking ohnehin nicht realistisch.
 * Wer "mitlaufende" Kreise braucht, zeichnet aktuell mehrere kurze Strokes hintereinander
 * (Keyframe-Ansatz) - siehe VideoAnnotationViewModel.
 */
@Serializable
data class DrawingStroke(
    val id: String = "",
    val tool: DrawingTool = DrawingTool.FREEHAND,
    val points: List<PitchPosition> = emptyList(),
    val colorHex: String = "#FF3B30",
    val strokeWidth: Float = 6f,
    val showFromMs: Long = 0,
    val showUntilMs: Long = 0
)

@Serializable
data class VideoAnnotation(
    val id: String = "",
    val teamId: String = "",
    val videoUrl: String = "", // Firebase Storage URL oder lokaler Pfad (offline)
    val title: String = "",
    val eventTag: EventTag? = null, // Verknüpfung zu Spielereignis
    val strokes: List<DrawingStroke> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Einfache Event-Verschlagwortung, manuell durch den Analysten gesetzt.
 * (Kein automatischer Opta/Stats-Perform-Feed - für Amateurbereich nicht verfügbar/nötig;
 * Trainer/Analyst tippt die Marker während oder nach dem Spiel selbst.)
 */
@Serializable
data class EventTag(
    val type: EventType,
    val timestampMs: Long,
    val playerId: String? = null,
    val note: String = ""
)

enum class EventType { GOAL, SHOT, KEY_PASS, FOUL, TACKLE, SET_PIECE, SUBSTITUTION, CARD, OTHER }
