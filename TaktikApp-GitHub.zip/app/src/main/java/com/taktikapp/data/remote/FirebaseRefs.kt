package com.taktikapp.data.remote

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await

/**
 * Zentrale Firebase-Zugriffsschicht.
 *
 * Sync-Strategie: "Local-first". Die App schreibt IMMER zuerst in Room (needsSync = true),
 * die UI reagiert sofort darauf. Ein WorkManager-Job (siehe SyncWorker) versucht anschließend,
 * alle "needsSync"-Einträge nach Firestore zu spiegeln, sobald eine Verbindung besteht.
 * Das deckt den Anwendungsfall "Analyst schneidet in der Kabine ohne Empfang" ab.
 */
object FirebaseRefs {
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }

    fun teamsCollection() = firestore.collection("teams")
    fun playersCollection(teamId: String) = teamsCollection().document(teamId).collection("players")
    fun formationsCollection(teamId: String) = teamsCollection().document(teamId).collection("formations")
    fun setPiecesCollection(teamId: String) = teamsCollection().document(teamId).collection("setPieces")
    fun videoAnnotationsCollection(teamId: String) = teamsCollection().document(teamId).collection("videoAnnotations")

    /**
     * Lädt ein lokal aufgenommenes/geschnittenes Video-Clip nach Firebase Storage hoch,
     * damit der Cheftrainer es Sekunden später auf dem Tablet in der Kabine hat.
     */
    suspend fun uploadClip(teamId: String, localFileUri: Uri, fileName: String): String {
        val ref = storage.reference.child("teams/$teamId/clips/$fileName")
        ref.putFile(localFileUri).await()
        return ref.downloadUrl.await().toString()
    }
}
