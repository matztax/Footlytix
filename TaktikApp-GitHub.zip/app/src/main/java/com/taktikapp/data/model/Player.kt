package com.taktikapp.data.model

import kotlinx.serialization.Serializable

/**
 * Ein Spieler im Kader. deviceToken wird für Push-Benachrichtigungen
 * (individuelle Clips/Briefings) über Firebase Cloud Messaging genutzt.
 */
@Serializable
data class Player(
    val id: String = "",
    val teamId: String = "",
    val name: String = "",
    val shirtNumber: Int = 0,
    val preferredPosition: PositionType = PositionType.CM,
    val deviceToken: String? = null, // FCM-Token für Push an Spieler-Smartphone
    val isInjured: Boolean = false
)

enum class PositionType {
    GK, LB, CB, RB, LWB, RWB, CDM, CM, CAM, LM, RM, LW, RW, ST, CF
}
