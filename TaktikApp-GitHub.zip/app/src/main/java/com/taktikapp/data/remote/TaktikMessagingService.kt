package com.taktikapp.data.remote

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Empfängt Push-Nachrichten für individuelle Clips/Briefings ("Spieler-App-Anbindung").
 *
 * Ablauf:
 * 1. Trainer/Analyst weist im Video-Modul einen Clip einem oder mehreren Spielern zu.
 * 2. Cloud Function (serverseitig, nicht Teil dieses Grundgerüsts) sendet Push an deviceToken.
 * 3. Spieler öffnet die Notification -> App markiert "gelesen" -> schreibt readReceipt nach
 *    Firestore (players/{playerId}/briefingReceipts/{clipId}), der Trainer sieht den Status.
 *
 * Hinweis: Das serverseitige Zustellen (Cloud Function, die den FCM-Send-Call macht) ist
 * bewusst nicht Teil des Client-Grundgerüsts - das gehört ins separate Firebase-Functions-Projekt.
 */
class TaktikMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // TODO: token an Firestore-Player-Dokument des eingeloggten Spielers schreiben
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val clipId = message.data["clipId"] ?: return
        val title = message.data["title"] ?: "Neues Taktik-Briefing"
        // TODO: lokale Notification anzeigen, die beim Öffnen zur VideoAnnotationScreen
        // mit diesem clipId navigiert und den Lesestatus in Firestore aktualisiert.
    }
}
