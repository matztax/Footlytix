package com.taktikapp.data.repository

import com.taktikapp.data.local.dao.PlayerDao
import com.taktikapp.data.local.dao.TeamDao
import com.taktikapp.data.local.entity.PlayerEntity
import com.taktikapp.data.local.entity.TeamEntity
import com.taktikapp.data.model.Player
import com.taktikapp.data.model.PositionType
import com.taktikapp.data.model.Team
import com.taktikapp.data.remote.FirebaseRefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.UUID

class TeamRepository(
    private val teamDao: TeamDao,
    private val playerDao: PlayerDao
) {
    fun observeTeamWithPlayers(teamId: String): Flow<Team?> =
        combine(teamDao.observeTeam(teamId), playerDao.observePlayers(teamId)) { team, players ->
            team?.let {
                Team(
                    id = it.id,
                    name = it.name,
                    coachUserId = it.coachUserId,
                    players = players.map { p -> p.toModel() }
                )
            }
        }

    fun observePlayers(teamId: String): Flow<List<Player>> =
        playerDao.observePlayers(teamId).map { list -> list.map { it.toModel() } }

    suspend fun saveTeam(team: Team) {
        val id = team.id.ifBlank { UUID.randomUUID().toString() }
        teamDao.upsert(TeamEntity(id, team.name, team.coachUserId, needsSync = true))
    }

    suspend fun savePlayer(teamId: String, player: Player) {
        val id = player.id.ifBlank { UUID.randomUUID().toString() }
        playerDao.upsert(
            PlayerEntity(
                id = id, teamId = teamId, name = player.name, shirtNumber = player.shirtNumber,
                preferredPosition = player.preferredPosition.name, deviceToken = player.deviceToken,
                isInjured = player.isInjured, needsSync = true
            )
        )
    }

    suspend fun deletePlayer(player: Player) {
        playerDao.delete(
            PlayerEntity(
                player.id, player.teamId, player.name, player.shirtNumber,
                player.preferredPosition.name, player.deviceToken, player.isInjured
            )
        )
    }

    suspend fun pushUnsyncedToCloud() {
        teamDao.getUnsyncedTeams().forEach { entity ->
            FirebaseRefs.teamsCollection().document(entity.id)
                .set(mapOf("id" to entity.id, "name" to entity.name, "coachUserId" to entity.coachUserId))
            teamDao.upsert(entity.copy(needsSync = false))
        }
        playerDao.getUnsyncedPlayers().forEach { entity ->
            FirebaseRefs.playersCollection(entity.teamId).document(entity.id).set(entity.toModel())
            playerDao.upsert(entity.copy(needsSync = false))
        }
    }

    private fun PlayerEntity.toModel() = Player(
        id = id, teamId = teamId, name = name, shirtNumber = shirtNumber,
        preferredPosition = PositionType.valueOf(preferredPosition),
        deviceToken = deviceToken, isInjured = isInjured
    )
}
