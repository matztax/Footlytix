package com.taktikapp.data.repository

import com.taktikapp.data.local.dao.SetPieceDao
import com.taktikapp.data.local.entity.JsonUtil
import com.taktikapp.data.local.entity.SetPieceEntity
import com.taktikapp.data.model.SetPiece
import com.taktikapp.data.model.SetPieceAssignment
import com.taktikapp.data.model.SetPieceType
import com.taktikapp.data.remote.FirebaseRefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import java.util.UUID

class SetPieceRepository(private val dao: SetPieceDao) {

    fun observeSetPieces(teamId: String): Flow<List<SetPiece>> =
        dao.observeSetPieces(teamId).map { list -> list.map { it.toModel() } }

    suspend fun saveSetPiece(setPiece: SetPiece) {
        val id = setPiece.id.ifBlank { UUID.randomUUID().toString() }
        dao.upsert(setPiece.copy(id = id).toEntity(needsSync = true))
    }

    suspend fun deleteSetPiece(setPiece: SetPiece) {
        dao.delete(setPiece.toEntity(needsSync = false))
    }

    suspend fun pushUnsyncedToCloud() {
        dao.getUnsynced().forEach { entity ->
            FirebaseRefs.setPiecesCollection(entity.teamId).document(entity.id).set(entity.toModel())
            dao.upsert(entity.copy(needsSync = false))
        }
    }

    private fun SetPieceEntity.toModel(): SetPiece {
        val assignments: List<SetPieceAssignment> = JsonUtil.json.decodeFromString(assignmentsJson)
        return SetPiece(
            id = id, teamId = teamId, name = name, type = SetPieceType.valueOf(type),
            assignments = assignments, notes = notes, linkedVideoAnnotationId = linkedVideoAnnotationId
        )
    }

    private fun SetPiece.toEntity(needsSync: Boolean) = SetPieceEntity(
        id = id, teamId = teamId, name = name, type = type.name,
        assignmentsJson = JsonUtil.json.encodeToString(assignments),
        notes = notes, linkedVideoAnnotationId = linkedVideoAnnotationId, needsSync = needsSync
    )
}
