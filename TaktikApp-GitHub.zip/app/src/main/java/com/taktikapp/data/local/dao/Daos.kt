package com.taktikapp.data.local.dao

import androidx.room.*
import com.taktikapp.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TeamDao {
    @Query("SELECT * FROM teams WHERE id = :teamId")
    fun observeTeam(teamId: String): Flow<TeamEntity?>

    @Query("SELECT * FROM teams")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Upsert
    suspend fun upsert(team: TeamEntity)

    @Query("SELECT * FROM teams WHERE needsSync = 1")
    suspend fun getUnsyncedTeams(): List<TeamEntity>
}

@Dao
interface PlayerDao {
    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY shirtNumber ASC")
    fun observePlayers(teamId: String): Flow<List<PlayerEntity>>

    @Upsert
    suspend fun upsert(player: PlayerEntity)

    @Upsert
    suspend fun upsertAll(players: List<PlayerEntity>)

    @Delete
    suspend fun delete(player: PlayerEntity)

    @Query("SELECT * FROM players WHERE needsSync = 1")
    suspend fun getUnsyncedPlayers(): List<PlayerEntity>
}

@Dao
interface FormationDao {
    @Query("SELECT * FROM formations WHERE teamId = :teamId ORDER BY updatedAt DESC")
    fun observeFormations(teamId: String): Flow<List<FormationEntity>>

    @Query("SELECT * FROM formations WHERE id = :id")
    suspend fun getById(id: String): FormationEntity?

    @Upsert
    suspend fun upsert(formation: FormationEntity)

    @Delete
    suspend fun delete(formation: FormationEntity)

    @Query("SELECT * FROM formations WHERE needsSync = 1")
    suspend fun getUnsynced(): List<FormationEntity>
}

@Dao
interface SetPieceDao {
    @Query("SELECT * FROM set_pieces WHERE teamId = :teamId")
    fun observeSetPieces(teamId: String): Flow<List<SetPieceEntity>>

    @Upsert
    suspend fun upsert(setPiece: SetPieceEntity)

    @Delete
    suspend fun delete(setPiece: SetPieceEntity)

    @Query("SELECT * FROM set_pieces WHERE needsSync = 1")
    suspend fun getUnsynced(): List<SetPieceEntity>
}

@Dao
interface VideoAnnotationDao {
    @Query("SELECT * FROM video_annotations WHERE teamId = :teamId ORDER BY createdAt DESC")
    fun observeAnnotations(teamId: String): Flow<List<VideoAnnotationEntity>>

    @Query("SELECT * FROM video_annotations WHERE id = :id")
    suspend fun getById(id: String): VideoAnnotationEntity?

    @Upsert
    suspend fun upsert(annotation: VideoAnnotationEntity)

    @Delete
    suspend fun delete(annotation: VideoAnnotationEntity)

    @Query("SELECT * FROM video_annotations WHERE needsSync = 1")
    suspend fun getUnsynced(): List<VideoAnnotationEntity>
}
