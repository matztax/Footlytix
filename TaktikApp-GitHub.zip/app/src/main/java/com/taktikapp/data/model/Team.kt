package com.taktikapp.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Team(
    val id: String = "",
    val name: String = "",
    val coachUserId: String = "",
    val players: List<Player> = emptyList()
)
