package com.taktikapp.data.model

import kotlinx.serialization.Serializable

enum class SetPieceType { CORNER_LEFT, CORNER_RIGHT, FREEKICK_DIRECT, FREEKICK_INDIRECT, THROW_IN, PENALTY }

enum class SetPieceRole { TARGET, BLOCKER, SCREENER, SAFETY_COVER, KICKER, RUNNER }

@Serializable
data class SetPieceAssignment(
    val playerId: String,
    val role: SetPieceRole,
    val position: PitchPosition,
    val movementTarget: PitchPosition? = null // Laufweg-Ziel, falls Spieler sich bewegt
)

@Serializable
data class SetPiece(
    val id: String = "",
    val teamId: String = "",
    val name: String = "", // z.B. "Ecke kurz, Variante A"
    val type: SetPieceType = SetPieceType.CORNER_LEFT,
    val assignments: List<SetPieceAssignment> = emptyList(),
    val notes: String = "",
    val linkedVideoAnnotationId: String? = null // Verweis auf Beispielszene im Video
)
