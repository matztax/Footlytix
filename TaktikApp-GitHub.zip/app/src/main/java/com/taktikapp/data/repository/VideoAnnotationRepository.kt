package com.taktikapp.data.repository

import android.net.Uri
import com.taktikapp.data.local.dao.VideoAnnotationDao
import com.taktikapp.data.local.entity.JsonUtil
import com.taktikapp.data.local.entity.VideoAnnotationEntity
import com.taktikapp.data.model.DrawingStroke
import com.taktikapp.data.model.EventTag
import com.taktikapp.data.model.VideoAnnotation
import com.taktikapp.data.remote.FirebaseRefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import java.util.UUID

class VideoAnnotationRepository(private val dao: VideoAnnotationDao) {

    fun observeAnnotations(teamId: String): Flow<List<VideoAnnotation>> =
        dao.observeAnnotations(teamId).map { list -> list.map { it.toModel() } }

    suspend fun getById(id: String): VideoAnnotation? = dao.getById(id)?.toModel()

    /**
     * Speichert eine Annotation, die auf ein LOKALES Video zeigt (noch nicht hochgeladen).
     * So kann der Analyst offline in der Kabine/im Bus weiterarbeiten.
     */
    suspend fun saveLocalAnnotation(teamId: String, localVideoPath: String, annotation: VideoAnnotation) {
        val id = annotation.id.ifBlank { UUID.randomUUID().toString() }
        dao.upsert(
            annotation.copy(id = id, teamId = teamId).toEntity(
                needsSync = true,
                localFilePath = localVideoPath
            )
        )
    }

    suspend fun updateStrokes(annotationId: String, strokes: List<DrawingStroke>) {
        val existing = dao.getById(annotationId) ?: return
        dao.upsert(existing.copy(strokesJson = JsonUtil.json.encodeToString(strokes), needsSync = true))
    }

    /**
     * Lädt das lokale Video nach Firebase Storage hoch, sobald wieder eine Verbindung besteht,
     * und aktualisiert danach den Firestore-Eintrag mit der finalen URL, damit sie beim
     * Cheftrainer im Tablet in der Kabine ankommt.
     */
    suspend fun uploadAndSync(teamId: String, annotationId: String, localVideoUri: Uri) {
        val entity = dao.getById(annotationId) ?: return
        val remoteUrl = FirebaseRefs.uploadClip(teamId, localVideoUri, "$annotationId.mp4")
        val updated = entity.copy(videoUrl = remoteUrl, needsSync = false)
        dao.upsert(updated)
        FirebaseRefs.videoAnnotationsCollection(teamId).document(annotationId).set(updated.toModel())
        // TODO: Cloud Function auslösen, die Push an zugewiesene Spieler-deviceTokens sendet
    }

    suspend fun pushUnsyncedToCloud() {
        dao.getUnsynced().forEach { entity ->
            if (entity.localFilePath == null) { // nur Metadaten, kein Video-Upload nötig
                FirebaseRefs.videoAnnotationsCollection(entity.teamId).document(entity.id).set(entity.toModel())
                dao.upsert(entity.copy(needsSync = false))
            }
            // Fälle mit localFilePath != null werden explizit über uploadAndSync behandelt,
            // da dafür ein aktiver Upload-Fortschritt in der UI angezeigt werden sollte.
        }
    }

    private fun VideoAnnotationEntity.toModel(): VideoAnnotation {
        val strokes: List<DrawingStroke> = JsonUtil.json.decodeFromString(strokesJson)
        val eventTag: EventTag? = eventTagJson?.let { JsonUtil.json.decodeFromString(it) }
        return VideoAnnotation(
            id = id, teamId = teamId, videoUrl = videoUrl, title = title,
            eventTag = eventTag, strokes = strokes, createdAt = createdAt
        )
    }

    private fun VideoAnnotation.toEntity(needsSync: Boolean, localFilePath: String?) = VideoAnnotationEntity(
        id = id, teamId = teamId, videoUrl = videoUrl, localFilePath = localFilePath, title = title,
        eventTagJson = eventTag?.let { JsonUtil.json.encodeToString(it) },
        strokesJson = JsonUtil.json.encodeToString(strokes), createdAt = createdAt, needsSync = needsSync
    )
}
