package com.taktikapp.data.repository

import com.taktikapp.data.local.dao.FormationDao
import com.taktikapp.data.local.entity.FormationEntity
import com.taktikapp.data.local.entity.JsonUtil
import com.taktikapp.data.model.Formation
import com.taktikapp.data.model.FormationPhase
import com.taktikapp.data.remote.FirebaseRefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

class FormationRepository(private val dao: FormationDao) {

    fun observeFormations(teamId: String): Flow<List<Formation>> =
        dao.observeFormations(teamId).map { list -> list.map { it.toModel() } }

    /**
     * Speichert immer zuerst lokal (offline-sicher). needsSync=true markiert den Eintrag
     * für den nächsten Lauf von SyncWorker.
     */
    suspend fun saveFormation(formation: Formation) {
        val id = formation.id.ifBlank { UUID.randomUUID().toString() }
        dao.upsert(formation.copy(id = id, updatedAt = System.currentTimeMillis()).toEntity(needsSync = true))
    }

    suspend fun deleteFormation(formation: Formation) {
        dao.delete(formation.toEntity(needsSync = false))
    }

    /** Wird vom SyncWorker aufgerufen, sobald wieder eine Verbindung besteht. */
    suspend fun pushUnsyncedToCloud() {
        val unsynced = dao.getUnsynced()
        unsynced.forEach { entity ->
            FirebaseRefs.formationsCollection(entity.teamId)
                .document(entity.id)
                .set(entity.toModel())
            dao.upsert(entity.copy(needsSync = false))
        }
    }

    private fun FormationEntity.toModel(): Formation {
        val phases: List<FormationPhase> = JsonUtil.json.decodeFromString(phasesJson)
        return Formation(
            id = id, teamId = teamId, title = title, systemLabel = systemLabel,
            opponentSystemLabel = opponentSystemLabel, phases = phases, updatedAt = updatedAt
        )
    }

    private fun Formation.toEntity(needsSync: Boolean): FormationEntity = FormationEntity(
        id = id, teamId = teamId, title = title, systemLabel = systemLabel,
        opponentSystemLabel = opponentSystemLabel,
        phasesJson = JsonUtil.json.encodeToString(phases),
        updatedAt = updatedAt, needsSync = needsSync
    )
}
