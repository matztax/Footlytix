package com.taktikapp.data.repository

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.taktikapp.data.local.AppDatabase

/**
 * Zentraler Hintergrund-Sync-Job. Wird ausgelöst:
 *  - periodisch (z.B. alle 15 Min, solange die App offen ist)
 *  - sofort, wenn ein NetworkCallback meldet, dass wieder eine Verbindung besteht
 *
 * Deckt exakt den Use-Case ab: "Analyst schneidet auf der Tribüne/im Bus ohne WLAN,
 * Cheftrainer hat es Sekunden später auf dem Tablet in der Kabine" - sobald wieder
 * Empfang da ist, läuft dieser Worker automatisch.
 */
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val db = AppDatabase.getInstance(applicationContext)
            TeamRepository(db.teamDao(), db.playerDao()).pushUnsyncedToCloud()
            FormationRepository(db.formationDao()).pushUnsyncedToCloud()
            SetPieceRepository(db.setPieceDao()).pushUnsyncedToCloud()
            VideoAnnotationRepository(db.videoAnnotationDao()).pushUnsyncedToCloud()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
