package com.taktikapp.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.taktikapp.ui.screens.formation.FormationBoardScreen
import com.taktikapp.ui.screens.formation.FormationBoardViewModel
import com.taktikapp.ui.screens.home.HomeScreen
import com.taktikapp.ui.screens.setpiece.SetPieceScreen
import com.taktikapp.ui.screens.setpiece.SetPieceViewModel
import com.taktikapp.ui.screens.team.TeamScreen
import com.taktikapp.ui.screens.team.TeamViewModel
import com.taktikapp.ui.screens.video.VideoAnnotationScreen
import com.taktikapp.ui.screens.video.VideoAnnotationViewModel
import java.util.UUID

// Für das Grundgerüst arbeiten wir mit einer festen Demo-Team-ID, bis Auth/Vereinsauswahl
// (Firebase Auth + Team-Erstellung) als eigener Screen ergänzt wird.
private const val DEMO_TEAM_ID = "demo-team"

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current

    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                teamName = "Mein Verein",
                onOpenTeam = { navController.navigate(Screen.Team.build(DEMO_TEAM_ID)) },
                onOpenFormations = {
                    navController.navigate(Screen.FormationBoard.build(DEMO_TEAM_ID, UUID.randomUUID().toString()))
                },
                onOpenSetPieces = { navController.navigate(Screen.SetPieces.build(DEMO_TEAM_ID)) },
                onOpenVideoLibrary = {
                    navController.navigate(Screen.VideoAnnotation.build(DEMO_TEAM_ID, UUID.randomUUID().toString()))
                },
                onOpenPlayerBriefing = { navController.navigate(Screen.PlayerBriefing.build(DEMO_TEAM_ID)) }
            )
        }

        composable(Screen.Team.route) {
            val vm: TeamViewModel = viewModel(factory = AppViewModelFactory(context, DEMO_TEAM_ID))
            TeamScreen(viewModel = vm, onBack = navController::popBackStack)
        }

        composable(Screen.FormationBoard.route) { backStackEntry ->
            val formationId = backStackEntry.arguments?.getString("formationId") ?: ""
            val vm: FormationBoardViewModel = viewModel(
                factory = AppViewModelFactory(context, DEMO_TEAM_ID, formationId = formationId)
            )
            FormationBoardScreen(viewModel = vm, onBack = navController::popBackStack)
        }

        composable(Screen.SetPieces.route) {
            val vm: SetPieceViewModel = viewModel(factory = AppViewModelFactory(context, DEMO_TEAM_ID))
            SetPieceScreen(viewModel = vm, onBack = navController::popBackStack)
        }

        composable(Screen.VideoAnnotation.route) { backStackEntry ->
            val annotationId = backStackEntry.arguments?.getString("annotationId") ?: ""
            val vm: VideoAnnotationViewModel = viewModel(
                factory = AppViewModelFactory(context, DEMO_TEAM_ID, annotationId = annotationId)
            )
            // TODO: videoUri aus einem Video-/Dateiauswahl-Screen übergeben (Storage Access Framework).
            VideoAnnotationScreen(viewModel = vm, videoUri = null as Uri?, onBack = navController::popBackStack)
        }

        composable(Screen.PlayerBriefing.route) {
            // TODO: echte Spieler/Annotationen/Lesestatus aus den Repositories laden
            // und über einen eigenen PlayerBriefingViewModel bereitstellen.
        }
    }
}

fun NavHostController.navigateBack() = popBackStack()
