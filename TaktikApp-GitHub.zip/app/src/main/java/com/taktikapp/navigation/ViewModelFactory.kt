package com.taktikapp.navigation

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.taktikapp.data.local.AppDatabase
import com.taktikapp.data.repository.FormationRepository
import com.taktikapp.data.repository.SetPieceRepository
import com.taktikapp.data.repository.TeamRepository
import com.taktikapp.data.repository.VideoAnnotationRepository
import com.taktikapp.ui.screens.formation.FormationBoardViewModel
import com.taktikapp.ui.screens.setpiece.SetPieceViewModel
import com.taktikapp.ui.screens.team.TeamViewModel
import com.taktikapp.ui.screens.video.VideoAnnotationViewModel

/**
 * Bewusst simple manuelle DI statt Hilt/Koin, damit das Grundgerüst ohne zusätzliche
 * Build-Konfiguration sofort baubar bleibt. Für eine wachsende Codebasis sollte das
 * mittelfristig durch Hilt ersetzt werden.
 */
class AppViewModelFactory(
    private val context: Context,
    private val teamId: String,
    private val formationId: String = "",
    private val annotationId: String = ""
) : ViewModelProvider.Factory {

    private val db by lazy { AppDatabase.getInstance(context) }

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val teamRepo = TeamRepository(db.teamDao(), db.playerDao())
        return when (modelClass) {
            FormationBoardViewModel::class.java ->
                FormationBoardViewModel(teamId, FormationRepository(db.formationDao()), teamRepo) as T
            SetPieceViewModel::class.java ->
                SetPieceViewModel(teamId, SetPieceRepository(db.setPieceDao()), teamRepo) as T
            TeamViewModel::class.java ->
                TeamViewModel(teamId, teamRepo) as T
            VideoAnnotationViewModel::class.java ->
                VideoAnnotationViewModel(teamId, annotationId, VideoAnnotationRepository(db.videoAnnotationDao())) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: $modelClass")
        }
    }
}
