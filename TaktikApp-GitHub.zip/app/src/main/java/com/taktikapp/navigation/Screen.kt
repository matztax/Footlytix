package com.taktikapp.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Team : Screen("team/{teamId}") {
        fun build(teamId: String) = "team/$teamId"
    }
    data object FormationList : Screen("formations/{teamId}") {
        fun build(teamId: String) = "formations/$teamId"
    }
    data object FormationBoard : Screen("formation_board/{teamId}/{formationId}") {
        fun build(teamId: String, formationId: String) = "formation_board/$teamId/$formationId"
    }
    data object SetPieces : Screen("set_pieces/{teamId}") {
        fun build(teamId: String) = "set_pieces/$teamId"
    }
    data object VideoLibrary : Screen("video_library/{teamId}") {
        fun build(teamId: String) = "video_library/$teamId"
    }
    data object VideoAnnotation : Screen("video_annotation/{teamId}/{annotationId}") {
        fun build(teamId: String, annotationId: String) = "video_annotation/$teamId/$annotationId"
    }
    data object PlayerBriefing : Screen("player_briefing/{teamId}") {
        fun build(teamId: String) = "player_briefing/$teamId"
    }
}
