package com.taktikapp.ui.screens.setpiece

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.taktikapp.data.model.PitchPosition
import com.taktikapp.data.model.SetPieceRole
import com.taktikapp.data.model.SetPieceType

private fun roleColor(role: SetPieceRole): Color = when (role) {
    SetPieceRole.TARGET -> Color(0xFFE53935)
    SetPieceRole.BLOCKER -> Color(0xFFFB8C00)
    SetPieceRole.SCREENER -> Color(0xFFFDD835)
    SetPieceRole.SAFETY_COVER -> Color(0xFF43A047)
    SetPieceRole.KICKER -> Color(0xFF1E88E5)
    SetPieceRole.RUNNER -> Color(0xFF8E24AA)
}

private fun roleLabel(role: SetPieceRole): String = when (role) {
    SetPieceRole.TARGET -> "Zielspieler"
    SetPieceRole.BLOCKER -> "Blocker"
    SetPieceRole.SCREENER -> "Absteller"
    SetPieceRole.SAFETY_COVER -> "Absicherung"
    SetPieceRole.KICKER -> "Ausführender"
    SetPieceRole.RUNNER -> "Läufer"
}

@Composable
fun SetPieceScreen(viewModel: SetPieceViewModel, onBack: () -> Unit) {
    val state by viewModel.state.collectAsState()
    var boardWidth by remember { mutableStateOf(1) }
    var boardHeight by remember { mutableStateOf(1) }
    val density = LocalDensity.current
    var showNewDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.setPiece.name.ifBlank { "Standardsituation" }) },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } },
                actions = {
                    TextButton(onClick = { showNewDialog = true }) { Text("Neu") }
                    Button(onClick = viewModel::save) { Text("Speichern") }
                    Spacer(Modifier.width(8.dp))
                }
            )
        }
    ) { padding ->
        Row(modifier = Modifier.padding(padding).fillMaxSize()) {

            // Linke Spalte: Feld mit den positionierten Rollen
            Box(
                modifier = Modifier
                    .weight(2f)
                    .fillMaxHeight()
                    .padding(16.dp)
                    .background(Color(0xFF1B7A3D))
                    .onGloballyPositioned {
                        boardWidth = it.size.width
                        boardHeight = it.size.height
                    }
                    .pointerInput(state.selectedRoleToAssign) {
                        detectDragGestures { change, _ ->
                            // Tap-to-place: bei aktiver Rollenauswahl reicht ein Tap/Drag-Start
                        }
                    }
            ) {
                state.setPiece.assignments.forEach { assignment ->
                    val player = state.players.find { it.id == assignment.playerId }
                    val xDp = with(density) { (assignment.position.x * boardWidth).toDp() }
                    val yDp = with(density) { (assignment.position.y * boardHeight).toDp() }
                    Box(
                        modifier = Modifier
                            .offset(x = xDp - 20.dp, y = yDp - 20.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(roleColor(assignment.role))
                            .pointerInput(assignment.playerId) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val newX = (assignment.position.x + dragAmount.x / boardWidth).coerceIn(0.02f, 0.98f)
                                    val newY = (assignment.position.y + dragAmount.y / boardHeight).coerceIn(0.02f, 0.98f)
                                    viewModel.movePlayer(assignment.playerId, PitchPosition(newX, newY))
                                }
                            },
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Text(player?.shirtNumber?.toString() ?: "?", color = Color.White)
                    }
                }
            }

            // Rechte Spalte: Rollen wählen, dann Spieler antippen zum Zuweisen
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(16.dp)
            ) {
                Text("1. Rolle wählen", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                SetPieceRole.entries.forEach { role ->
                    FilterChip(
                        selected = state.selectedRoleToAssign == role,
                        onClick = { viewModel.selectRoleToAssign(role) },
                        label = { Text(roleLabel(role)) },
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }

                Spacer(Modifier.height(16.dp))
                Text("2. Spieler antippen", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                state.players.forEach { player ->
                    OutlinedButton(
                        onClick = {
                            viewModel.assignPlayerAtPosition(player.id, PitchPosition(0.5f, 0.5f))
                        },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Text("#${player.shirtNumber} ${player.name}")
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = state.setPiece.notes,
                    onValueChange = viewModel::updateNotes,
                    label = { Text("Notizen zur Variante") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    if (showNewDialog) {
        var name by remember { mutableStateOf("") }
        var type by remember { mutableStateOf(SetPieceType.CORNER_LEFT) }
        AlertDialog(
            onDismissRequest = { showNewDialog = false },
            title = { Text("Neue Standardsituation") },
            text = {
                Column {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") })
                    Spacer(Modifier.height(8.dp))
                    LazyRow {
                        items(SetPieceType.entries.toList()) { t ->
                            FilterChip(
                                selected = type == t,
                                onClick = { type = t },
                                label = { Text(t.name) },
                                modifier = Modifier.padding(2.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.newSetPiece(type, name.ifBlank { "Neue Standardsituation" })
                    showNewDialog = false
                }) { Text("Anlegen") }
            },
            dismissButton = { TextButton(onClick = { showNewDialog = false }) { Text("Abbrechen") } }
        )
    }
}
