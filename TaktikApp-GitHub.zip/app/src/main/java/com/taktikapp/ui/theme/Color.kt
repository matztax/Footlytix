package com.taktikapp.ui.theme

import androidx.compose.ui.graphics.Color

val PitchGreen = Color(0xFF1B7A3D)
val PitchGreenDark = Color(0xFF0F5C2A)
val TeamPrimary = Color(0xFF1565C0)
val AccentOrange = Color(0xFFFF6D00)
val SurfaceDark = Color(0xFF121212)
val OnSurfaceLight = Color(0xFFF5F5F5)
