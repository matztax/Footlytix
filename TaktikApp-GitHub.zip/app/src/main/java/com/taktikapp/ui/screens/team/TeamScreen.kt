package com.taktikapp.ui.screens.team

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.taktikapp.data.model.PositionType

@Composable
fun TeamScreen(viewModel: TeamViewModel, onBack: () -> Unit) {
    val team by viewModel.team.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(team?.name ?: "Kader") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } },
                actions = { TextButton(onClick = { showAddDialog = true }) { Text("+ Spieler") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            items(team?.players.orEmpty()) { player ->
                ListItem(
                    headlineContent = { Text("#${player.shirtNumber} ${player.name}") },
                    supportingContent = { Text(player.preferredPosition.name + if (player.isInjured) " · verletzt" else "") },
                    trailingContent = {
                        Row {
                            TextButton(onClick = { viewModel.toggleInjured(player) }) {
                                Text(if (player.isInjured) "Fit melden" else "Verletzt melden")
                            }
                            IconButton(onClick = { viewModel.removePlayer(player) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Entfernen")
                            }
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var number by remember { mutableStateOf("") }
        var position by remember { mutableStateOf(PositionType.CM) }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Spieler hinzufügen") },
            text = {
                Column {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = number, onValueChange = { number = it.filter { c -> c.isDigit() } },
                        label = { Text("Rückennummer") }
                    )
                    Spacer(Modifier.height(8.dp))
                    ExposedPositionDropdown(position) { position = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addPlayer(name, number.toIntOrNull() ?: 0, position)
                    }
                    showAddDialog = false
                }) { Text("Hinzufügen") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Abbrechen") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExposedPositionDropdown(selected: PositionType, onSelected: (PositionType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected.name,
            onValueChange = {},
            readOnly = true,
            label = { Text("Position") },
            modifier = Modifier.menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            PositionType.entries.forEach { pos ->
                DropdownMenuItem(text = { Text(pos.name) }, onClick = { onSelected(pos); expanded = false })
            }
        }
    }
}
