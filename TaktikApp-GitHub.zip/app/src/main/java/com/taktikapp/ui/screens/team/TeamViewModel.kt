package com.taktikapp.ui.screens.team

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taktikapp.data.model.Player
import com.taktikapp.data.model.PositionType
import com.taktikapp.data.model.Team
import com.taktikapp.data.repository.TeamRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TeamViewModel(
    private val teamId: String,
    private val repo: TeamRepository
) : ViewModel() {

    private val _team = MutableStateFlow<Team?>(null)
    val team: StateFlow<Team?> = _team.asStateFlow()

    init {
        viewModelScope.launch {
            repo.observeTeamWithPlayers(teamId).collect { _team.value = it }
        }
    }

    fun addPlayer(name: String, shirtNumber: Int, position: PositionType) {
        viewModelScope.launch {
            repo.savePlayer(teamId, Player(teamId = teamId, name = name, shirtNumber = shirtNumber, preferredPosition = position))
        }
    }

    fun removePlayer(player: Player) {
        viewModelScope.launch { repo.deletePlayer(player) }
    }

    fun toggleInjured(player: Player) {
        viewModelScope.launch {
            repo.savePlayer(teamId, player.copy(isInjured = !player.isInjured))
        }
    }
}
