package com.taktikapp.ui.screens.video

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taktikapp.data.model.DrawingStroke
import com.taktikapp.data.model.DrawingTool
import com.taktikapp.data.model.VideoAnnotation
import com.taktikapp.data.repository.VideoAnnotationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class VideoAnnotationState(
    val annotation: VideoAnnotation? = null,
    val currentPositionMs: Long = 0,
    val isDrawingEnabled: Boolean = false,
    val activeTool: DrawingTool = DrawingTool.ARROW,
    val activeColorHex: String = "#FF3B30",
    val isUploading: Boolean = false
)

class VideoAnnotationViewModel(
    private val teamId: String,
    private val annotationId: String,
    private val repo: VideoAnnotationRepository
) : ViewModel() {

    private val _state = MutableStateFlow(VideoAnnotationState())
    val state: StateFlow<VideoAnnotationState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val existing = repo.getById(annotationId)
            _state.value = _state.value.copy(annotation = existing)
        }
    }

    fun createNew(localVideoPath: String, title: String) {
        viewModelScope.launch {
            val annotation = VideoAnnotation(id = annotationId, teamId = teamId, title = title, videoUrl = localVideoPath)
            repo.saveLocalAnnotation(teamId, localVideoPath, annotation)
            _state.value = _state.value.copy(annotation = annotation)
        }
    }

    fun onPositionChanged(positionMs: Long) {
        _state.value = _state.value.copy(currentPositionMs = positionMs)
    }

    fun toggleDrawingMode() {
        _state.value = _state.value.copy(isDrawingEnabled = !_state.value.isDrawingEnabled)
    }

    fun selectTool(tool: DrawingTool) {
        _state.value = _state.value.copy(activeTool = tool)
    }

    fun selectColor(hex: String) {
        _state.value = _state.value.copy(activeColorHex = hex)
    }

    fun onStrokeFinished(stroke: DrawingStroke) {
        val current = _state.value.annotation ?: return
        val updated = current.copy(strokes = current.strokes + stroke)
        _state.value = _state.value.copy(annotation = updated)
        viewModelScope.launch { repo.updateStrokes(current.id, updated.strokes) }
    }

    fun undoLastStroke() {
        val current = _state.value.annotation ?: return
        if (current.strokes.isEmpty()) return
        val updated = current.copy(strokes = current.strokes.dropLast(1))
        _state.value = _state.value.copy(annotation = updated)
        viewModelScope.launch { repo.updateStrokes(current.id, updated.strokes) }
    }

    /** Lädt den Clip hoch, sobald der Trainer/Analyst wieder Netz hat, z.B. am Trainingsgelände. */
    fun uploadWhenReady(localUri: Uri) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isUploading = true)
            try {
                repo.uploadAndSync(teamId, annotationId, localUri)
            } finally {
                _state.value = _state.value.copy(isUploading = false)
            }
        }
    }
}
