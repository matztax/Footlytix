package com.taktikapp.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class HomeModule(val title: String, val subtitle: String, val onClick: () -> Unit)

@Composable
fun HomeScreen(
    teamName: String,
    onOpenTeam: () -> Unit,
    onOpenFormations: () -> Unit,
    onOpenSetPieces: () -> Unit,
    onOpenVideoLibrary: () -> Unit,
    onOpenPlayerBriefing: () -> Unit
) {
    val modules = listOf(
        HomeModule("Kader", "Spieler, Positionen, Verfügbarkeit", onOpenTeam),
        HomeModule("Formationen", "Aufstellungen & Szenarien per Drag & Drop", onOpenFormations),
        HomeModule("Standardsituationen", "Ecken & Freistöße planen", onOpenSetPieces),
        HomeModule("Video-Analyse", "Zeichnen direkt im Spielvideo", onOpenVideoLibrary),
        HomeModule("Spieler-Briefings", "Clips gezielt versenden, Lesestatus sehen", onOpenPlayerBriefing)
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text(teamName) }) }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(modules) { module ->
                ElevatedCard(onClick = module.onClick, modifier = Modifier.fillMaxWidth().height(140.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(module.title, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text(module.subtitle, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
