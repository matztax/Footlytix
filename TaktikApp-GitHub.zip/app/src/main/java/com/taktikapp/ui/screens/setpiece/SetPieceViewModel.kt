package com.taktikapp.ui.screens.setpiece

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taktikapp.data.model.*
import com.taktikapp.data.repository.SetPieceRepository
import com.taktikapp.data.repository.TeamRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class SetPieceBoardState(
    val players: List<Player> = emptyList(),
    val setPiece: SetPiece = SetPiece(),
    val savedSetPieces: List<SetPiece> = emptyList(),
    val selectedRoleToAssign: SetPieceRole? = null
)

class SetPieceViewModel(
    private val teamId: String,
    private val repo: SetPieceRepository,
    private val teamRepo: TeamRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SetPieceBoardState())
    val state: StateFlow<SetPieceBoardState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            teamRepo.observePlayers(teamId).collect { players ->
                _state.value = _state.value.copy(players = players)
            }
        }
        viewModelScope.launch {
            repo.observeSetPieces(teamId).collect { list ->
                _state.value = _state.value.copy(savedSetPieces = list)
            }
        }
    }

    fun newSetPiece(type: SetPieceType, name: String) {
        _state.value = _state.value.copy(
            setPiece = SetPiece(teamId = teamId, name = name, type = type)
        )
    }

    fun loadSetPiece(setPiece: SetPiece) {
        _state.value = _state.value.copy(setPiece = setPiece)
    }

    fun selectRoleToAssign(role: SetPieceRole) {
        _state.value = _state.value.copy(selectedRoleToAssign = role)
    }

    /** Weist den angetippten Spieler der aktuell gewählten Rolle an der gegebenen Position zu. */
    fun assignPlayerAtPosition(playerId: String, position: PitchPosition) {
        val role = _state.value.selectedRoleToAssign ?: return
        val current = _state.value.setPiece
        val filtered = current.assignments.filter { it.playerId != playerId }
        val updated = filtered + SetPieceAssignment(playerId, role, position)
        _state.value = _state.value.copy(
            setPiece = current.copy(assignments = updated),
            selectedRoleToAssign = null
        )
    }

    fun movePlayer(playerId: String, position: PitchPosition) {
        val current = _state.value.setPiece
        val updated = current.assignments.map {
            if (it.playerId == playerId) it.copy(position = position) else it
        }
        _state.value = _state.value.copy(setPiece = current.copy(assignments = updated))
    }

    fun updateNotes(notes: String) {
        _state.value = _state.value.copy(setPiece = _state.value.setPiece.copy(notes = notes))
    }

    fun save() {
        viewModelScope.launch {
            val toSave = _state.value.setPiece.let {
                if (it.id.isBlank()) it.copy(id = UUID.randomUUID().toString()) else it
            }
            repo.saveSetPiece(toSave)
        }
    }
}
