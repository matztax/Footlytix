package com.taktikapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Ein einzelner Spieler-Marker auf dem Feld. onDrag liefert das Delta in Pixeln;
 * die aufrufende Screen rechnet das in normalisierte Feldkoordinaten (0..1) um,
 * damit die Formation geräteunabhängig gespeichert wird.
 */
@Composable
fun PlayerToken(
    shirtNumber: Int,
    color: Color = MaterialTheme.colorScheme.primary,
    onDrag: (dx: Float, dy: Float) -> Unit,
    onDragEnd: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(color, CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        onDrag(dragAmount.x, dragAmount.y)
                    },
                    onDragEnd = onDragEnd
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = shirtNumber.toString(),
            color = Color.White,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
