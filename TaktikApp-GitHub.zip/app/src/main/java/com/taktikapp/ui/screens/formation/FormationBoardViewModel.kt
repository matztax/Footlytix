package com.taktikapp.ui.screens.formation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taktikapp.data.model.Formation
import com.taktikapp.data.model.FormationPhase
import com.taktikapp.data.model.PitchPosition
import com.taktikapp.data.model.Player
import com.taktikapp.data.repository.FormationRepository
import com.taktikapp.data.repository.TeamRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class FormationBoardState(
    val players: List<Player> = emptyList(),
    val formation: Formation = Formation(),
    val activePhaseIndex: Int = 0
)

/**
 * Verwaltet eine Formation mit mehreren "Phasen" - z.B. Grundordnung und die Verschiebung
 * als Reaktion auf einen gegnerischen Systemwechsel. Der Trainer kann zwischen Phasen
 * wechseln, um Laufwege/Pressing-Trigger zu simulieren (kein Echtzeit-Physik-Solver,
 * sondern manuell gesetzte Zielpositionen je Phase - für Amateurniveau ausreichend
 * und nachvollziehbar erklärbar).
 */
class FormationBoardViewModel(
    private val teamId: String,
    private val formationRepo: FormationRepository,
    private val teamRepo: TeamRepository
) : ViewModel() {

    private val _state = MutableStateFlow(FormationBoardState())
    val state: StateFlow<FormationBoardState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            teamRepo.observePlayers(teamId).collect { players ->
                _state.value = _state.value.copy(players = players)
                if (_state.value.formation.phases.isEmpty() && players.isNotEmpty()) {
                    initDefaultFormation(players)
                }
            }
        }
    }

    fun loadFormation(formation: Formation) {
        _state.value = _state.value.copy(formation = formation, activePhaseIndex = 0)
    }

    private fun initDefaultFormation(players: List<Player>) {
        // einfache Standard-Startaufstellung: erste 11 Spieler gleichmäßig verteilt
        val positions = defaultFourThreeThreeLayout()
        val playerPositions = players.take(11).mapIndexed { idx, p ->
            p.id to (positions.getOrNull(idx) ?: PitchPosition(0.5f, 0.5f))
        }.toMap()

        val phase = FormationPhase(
            id = UUID.randomUUID().toString(),
            label = "Grundordnung",
            playerPositions = playerPositions
        )
        _state.value = _state.value.copy(
            formation = Formation(teamId = teamId, title = "Neue Formation", systemLabel = "4-3-3", phases = listOf(phase))
        )
    }

    fun addPhase(label: String) {
        val current = _state.value.formation
        val basePhase = current.phases.getOrNull(_state.value.activePhaseIndex) ?: return
        val newPhase = basePhase.copy(id = UUID.randomUUID().toString(), label = label)
        val updated = current.copy(phases = current.phases + newPhase)
        _state.value = _state.value.copy(formation = updated, activePhaseIndex = updated.phases.lastIndex)
    }

    fun switchPhase(index: Int) {
        if (index in _state.value.formation.phases.indices) {
            _state.value = _state.value.copy(activePhaseIndex = index)
        }
    }

    /** dx/dy sind normalisierte Deltas (bereits durch die Boardgröße geteilt). */
    fun movePlayer(playerId: String, dx: Float, dy: Float) {
        val current = _state.value
        val phase = current.formation.phases.getOrNull(current.activePhaseIndex) ?: return
        val pos = phase.playerPositions[playerId] ?: return
        val newPos = PitchPosition(
            x = (pos.x + dx).coerceIn(0.02f, 0.98f),
            y = (pos.y + dy).coerceIn(0.02f, 0.98f)
        )
        val updatedPositions = phase.playerPositions.toMutableMap().apply { put(playerId, newPos) }
        val updatedPhase = phase.copy(playerPositions = updatedPositions)
        val updatedPhases = current.formation.phases.toMutableList().apply {
            set(current.activePhaseIndex, updatedPhase)
        }
        _state.value = current.copy(formation = current.formation.copy(phases = updatedPhases))
    }

    fun updateSystemLabel(label: String) {
        _state.value = _state.value.copy(formation = _state.value.formation.copy(systemLabel = label))
    }

    fun save() {
        viewModelScope.launch {
            formationRepo.saveFormation(_state.value.formation)
        }
    }

    private fun defaultFourThreeThreeLayout(): List<PitchPosition> = listOf(
        PitchPosition(0.06f, 0.5f),   // TW
        PitchPosition(0.20f, 0.15f),  // LV
        PitchPosition(0.18f, 0.38f),  // IV
        PitchPosition(0.18f, 0.62f),  // IV
        PitchPosition(0.20f, 0.85f),  // RV
        PitchPosition(0.42f, 0.30f),  // ZM
        PitchPosition(0.38f, 0.5f),   // ZDM
        PitchPosition(0.42f, 0.70f),  // ZM
        PitchPosition(0.72f, 0.15f),  // LA
        PitchPosition(0.80f, 0.5f),   // ST
        PitchPosition(0.72f, 0.85f)   // RA
    )
}
