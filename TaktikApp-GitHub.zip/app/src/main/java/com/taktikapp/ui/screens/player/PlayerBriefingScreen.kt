package com.taktikapp.ui.screens.player

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.taktikapp.data.model.Player
import com.taktikapp.data.model.VideoAnnotation

/**
 * Trainer wählt einen Clip und die Spieler aus, die ihn als individuelles Briefing
 * aufs Handy bekommen sollen. Der tatsächliche Push-Versand läuft serverseitig über
 * eine Firebase Cloud Function (siehe TaktikMessagingService.kt) - dieser Screen
 * schreibt nur die Zuweisung + beobachtet den Lesestatus aus Firestore.
 */
@Composable
fun PlayerBriefingScreen(
    players: List<Player>,
    annotations: List<VideoAnnotation>,
    readReceipts: Map<String, Set<String>>, // annotationId -> Set<playerId>, die es gelesen haben
    onAssign: (annotationId: String, playerIds: Set<String>) -> Unit,
    onBack: () -> Unit
) {
    var selectedAnnotation by remember { mutableStateOf<VideoAnnotation?>(null) }
    var selectedPlayerIds by remember { mutableStateOf(setOf<String>()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Briefings an Spieler") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Row(modifier = Modifier.padding(padding).fillMaxSize()) {
            Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp)) {
                Text("Clip wählen", style = MaterialTheme.typography.titleLarge)
                LazyColumn {
                    items(annotations) { annotation ->
                        val readCount = readReceipts[annotation.id]?.size ?: 0
                        ListItem(
                            headlineContent = { Text(annotation.title.ifBlank { "Unbenannter Clip" }) },
                            supportingContent = { Text("$readCount gelesen") },
                            trailingContent = {
                                RadioButton(
                                    selected = selectedAnnotation?.id == annotation.id,
                                    onClick = { selectedAnnotation = annotation }
                                )
                            }
                        )
                    }
                }
            }
            Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp)) {
                Text("Spieler zuweisen", style = MaterialTheme.typography.titleLarge)
                LazyColumn {
                    items(players) { player ->
                        val checked = selectedPlayerIds.contains(player.id)
                        ListItem(
                            headlineContent = { Text("#${player.shirtNumber} ${player.name}") },
                            trailingContent = {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        selectedPlayerIds = if (it) selectedPlayerIds + player.id
                                        else selectedPlayerIds - player.id
                                    }
                                )
                            }
                        )
                    }
                }
                Button(
                    onClick = {
                        selectedAnnotation?.let { onAssign(it.id, selectedPlayerIds) }
                    },
                    enabled = selectedAnnotation != null && selectedPlayerIds.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Senden") }
            }
        }
    }
}
