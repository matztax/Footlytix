package com.taktikapp.ui.screens.formation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.onGloballyPositioned
import androidx.compose.ui.unit.dp
import com.taktikapp.data.model.Player
import com.taktikapp.ui.components.PitchBackground
import com.taktikapp.ui.components.PlayerToken

/**
 * Taktiktafel: Spieler werden per Drag&Drop positioniert. Über die Phasen-Chips oben
 * kann der Trainer zwischen z.B. "Grundordnung" und "Verschiebung nach Systemwechsel
 * Gegner (4-2-3-1 -> 3-5-2)" wechseln, um Laufwege und Pressing-Trigger zu erklären.
 */
@Composable
fun FormationBoardScreen(
    viewModel: FormationBoardViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    var boardSize by remember { mutableStateOf(IntSize(1, 1)) }
    var showAddPhaseDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = state.formation.systemLabel,
                        onValueChange = viewModel::updateSystemLabel,
                        singleLine = true,
                        label = { Text("System") },
                        modifier = Modifier.width(140.dp)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Text("←") }
                },
                actions = {
                    TextButton(onClick = { showAddPhaseDialog = true }) { Text("+ Phase") }
                    Button(onClick = viewModel::save) { Text("Speichern") }
                    Spacer(Modifier.width(8.dp))
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            // Phasen-Umschalter: z.B. [Grundordnung] [Gegner wechselt auf 3-5-2] [+]
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.formation.phases.size) { index ->
                    val phase = state.formation.phases[index]
                    FilterChip(
                        selected = index == state.activePhaseIndex,
                        onClick = { viewModel.switchPhase(index) },
                        label = { Text(phase.label) }
                    )
                }
            }

            // Das eigentliche Spielfeld mit den Spieler-Tokens
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .onGloballyPositioned { boardSize = IntSize(it.size.width, it.size.height) }
            ) {
                PitchBackground(modifier = Modifier.fillMaxSize())

                val activePhase = state.formation.phases.getOrNull(state.activePhaseIndex)
                activePhase?.playerPositions?.forEach { (playerId, pos) ->
                    val player = state.players.find { it.id == playerId } ?: return@forEach
                    val xPx = pos.x * boardSize.width
                    val yPx = pos.y * boardSize.height

                    Box(
                        modifier = Modifier.offset(
                            x = with(LocalDensityProvider()) { xPx.toDp() } - 22.dp,
                            y = with(LocalDensityProvider()) { yPx.toDp() } - 22.dp
                        )
                    ) {
                        PlayerToken(
                            shirtNumber = player.shirtNumber,
                            onDrag = { dx, dy ->
                                if (boardSize.width > 0 && boardSize.height > 0) {
                                    viewModel.movePlayer(
                                        playerId,
                                        dx / boardSize.width,
                                        dy / boardSize.height
                                    )
                                }
                            }
                        )
                    }
                }
            }

            Text(
                text = "Tipp: Spieler ziehen, um Laufwege je Phase zu setzen. " +
                    "Automatisches Tracking aus Videomaterial ist bewusst nicht Teil dieses Moduls.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(16.dp)
            )
        }
    }

    if (showAddPhaseDialog) {
        var label by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddPhaseDialog = false },
            title = { Text("Neue Phase") },
            text = {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    placeholder = { Text("z.B. Gegner wechselt auf 3-5-2") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (label.isNotBlank()) viewModel.addPhase(label)
                    showAddPhaseDialog = false
                }) { Text("Anlegen") }
            },
            dismissButton = {
                TextButton(onClick = { showAddPhaseDialog = false }) { Text("Abbrechen") }
            }
        )
    }
}

data class IntSize(val width: Int, val height: Int)

@Composable
private fun LocalDensityProvider() = androidx.compose.ui.platform.LocalDensity.current
