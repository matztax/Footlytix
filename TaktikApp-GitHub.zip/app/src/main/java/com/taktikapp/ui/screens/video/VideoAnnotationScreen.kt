package com.taktikapp.ui.screens.video

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.taktikapp.data.model.DrawingTool
import com.taktikapp.ui.components.DrawingOverlay
import kotlinx.coroutines.delay

private val palette = listOf("#FF3B30", "#FFD60A", "#0A84FF", "#30D158", "#FFFFFF")

/**
 * Kernbildschirm der Video-Telestration: Video links/oben, Zeichen-Overlay darüber,
 * Werkzeugleiste zum Umschalten von Zeichenwerkzeug/Farbe, Undo, und
 * Play/Pause + Frame-genaue Navigation für die Erklärung einzelner Szenen.
 */
@Composable
fun VideoAnnotationScreen(
    viewModel: VideoAnnotationViewModel,
    videoUri: Uri?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            videoUri?.let { setMediaItem(MediaItem.fromUri(it)) }
            prepare()
        }
    }

    DisposableEffectCleanup(exoPlayer)

    // Wiedergabeposition regelmäßig abfragen, um die richtigen Strokes einzublenden
    LaunchedEffect(exoPlayer) {
        while (true) {
            viewModel.onPositionChanged(exoPlayer.currentPosition)
            delay(50)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.annotation?.title ?: "Video-Analyse") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } },
                actions = {
                    IconButton(onClick = viewModel::undoLastStroke) { Text("Undo") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer; useController = true } },
                    modifier = Modifier.fillMaxSize()
                )
                DrawingOverlay(
                    modifier = Modifier.fillMaxSize(),
                    strokes = state.annotation?.strokes ?: emptyList(),
                    currentPositionMs = state.currentPositionMs,
                    isDrawingEnabled = state.isDrawingEnabled,
                    activeTool = state.activeTool,
                    activeColorHex = state.activeColorHex,
                    onStrokeFinished = viewModel::onStrokeFinished
                )
            }

            // Werkzeugleiste
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = state.isDrawingEnabled,
                    onClick = viewModel::toggleDrawingMode,
                    label = { Text(if (state.isDrawingEnabled) "Zeichnen: AN" else "Zeichnen: AUS") }
                )
                Spacer(Modifier.width(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(DrawingTool.entries.toList()) { tool ->
                        FilterChip(
                            selected = state.activeTool == tool,
                            onClick = { viewModel.selectTool(tool) },
                            label = { Text(tool.name) }
                        )
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                palette.forEach { hex ->
                    ColorDot(hex = hex, selected = state.activeColorHex == hex) { viewModel.selectColor(hex) }
                    Spacer(Modifier.width(8.dp))
                }
            }

            if (state.isUploading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp))
                Text(
                    "Clip wird hochgeladen, sobald wieder Verbindung besteht…",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun ColorDot(hex: String, selected: Boolean, onClick: () -> Unit) {
    val color = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Red }
    Box(
        modifier = Modifier
            .size(if (selected) 32.dp else 26.dp)
            .clip(CircleShape)
            .background(color)
            .then(
                if (selected) Modifier.border(2.dp, Color.White, CircleShape)
                else Modifier
            )
            .clickable(onClick = onClick)
    )
}

@Composable
private fun DisposableEffectCleanup(exoPlayer: ExoPlayer) {
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }
}
