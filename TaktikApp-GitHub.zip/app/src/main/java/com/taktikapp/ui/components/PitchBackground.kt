package com.taktikapp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * Zeichnet ein stilisiertes Fußballfeld (Querformat, wie am Spielfeldrand/auf dem
 * Tablet in der Kabine üblich) als Hintergrund für Formation- und Set-Piece-Editoren.
 */
@Composable
fun PitchBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val lineColor = Color.White.copy(alpha = 0.55f)
        val strokeWidth = 3f

        drawRect(color = lineColor, style = Stroke(width = strokeWidth))

        // Mittellinie
        drawLine(
            color = lineColor,
            start = Offset(size.width / 2, 0f),
            end = Offset(size.width / 2, size.height),
            strokeWidth = strokeWidth
        )
        // Mittelkreis
        drawCircle(
            color = lineColor,
            radius = size.height * 0.16f,
            center = Offset(size.width / 2, size.height / 2),
            style = Stroke(width = strokeWidth)
        )

        val boxWidth = size.width * 0.16f
        val boxHeight = size.height * 0.5f
        // Strafraum links
        drawRect(
            color = lineColor,
            topLeft = Offset(0f, (size.height - boxHeight) / 2),
            size = androidx.compose.ui.geometry.Size(boxWidth, boxHeight),
            style = Stroke(width = strokeWidth)
        )
        // Strafraum rechts
        drawRect(
            color = lineColor,
            topLeft = Offset(size.width - boxWidth, (size.height - boxHeight) / 2),
            size = androidx.compose.ui.geometry.Size(boxWidth, boxHeight),
            style = Stroke(width = strokeWidth)
        )
    }
}
