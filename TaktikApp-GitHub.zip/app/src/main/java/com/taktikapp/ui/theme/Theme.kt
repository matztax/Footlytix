package com.taktikapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TaktikColorScheme = darkColorScheme(
    primary = TeamPrimary,
    secondary = AccentOrange,
    background = SurfaceDark,
    surface = Color(0xFF1E1E1E),
    onBackground = OnSurfaceLight,
    onSurface = OnSurfaceLight
)

@Composable
fun TaktikAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TaktikColorScheme,
        typography = TaktikTypography,
        content = content
    )
}
