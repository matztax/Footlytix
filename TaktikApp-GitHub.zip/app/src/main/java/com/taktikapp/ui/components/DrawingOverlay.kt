package com.taktikapp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.taktikapp.data.model.DrawingStroke
import com.taktikapp.data.model.DrawingTool
import com.taktikapp.data.model.PitchPosition

/**
 * Transparentes Overlay über dem Videobild. Zeigt nur die Strokes an, deren Zeitfenster
 * (showFromMs..showUntilMs) die aktuelle Wiedergabeposition enthält, und erlaubt im
 * Zeichenmodus das Erfassen eines neuen Strokes per Fingerzug.
 *
 * Bewusste Grenze: Punkte sind an feste Bildkoordinaten gebunden. Es gibt kein
 * automatisches Mitverfolgen von Spielern (kein Objekt-Tracking) - siehe VideoAnnotation.kt.
 */
@Composable
fun DrawingOverlay(
    modifier: Modifier = Modifier,
    strokes: List<DrawingStroke>,
    currentPositionMs: Long,
    isDrawingEnabled: Boolean,
    activeTool: DrawingTool,
    activeColorHex: String,
    onStrokeFinished: (DrawingStroke) -> Unit
) {
    var currentPoints by remember { mutableStateOf(listOf<Offset>()) }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(isDrawingEnabled, activeTool) {
                if (!isDrawingEnabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { offset -> currentPoints = listOf(offset) },
                    onDrag = { change, _ ->
                        change.consume()
                        currentPoints = currentPoints + change.position
                    },
                    onDragEnd = {
                        if (currentPoints.size >= 2 && size.width > 0 && size.height > 0) {
                            val normalized = currentPoints.map {
                                PitchPosition(it.x / size.width, it.y / size.height)
                            }
                            onStrokeFinished(
                                DrawingStroke(
                                    tool = activeTool,
                                    points = normalized,
                                    colorHex = activeColorHex,
                                    showFromMs = currentPositionMs,
                                    showUntilMs = currentPositionMs + 4000 // 4s sichtbar, editierbar
                                )
                            )
                        }
                        currentPoints = emptyList()
                    }
                )
            }
    ) {
        // Gespeicherte Strokes, die im aktuellen Zeitfenster liegen
        strokes.filter { currentPositionMs in it.showFromMs..it.showUntilMs }.forEach { stroke ->
            val color = try {
                Color(android.graphics.Color.parseColor(stroke.colorHex))
            } catch (e: Exception) { Color.Red }

            val path = androidx.compose.ui.graphics.Path()
            stroke.points.forEachIndexed { index, p ->
                val x = p.x * size.width
                val y = p.y * size.height
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = color, style = Stroke(width = stroke.strokeWidth))
        }

        // Aktuell in Erstellung befindlicher Stroke
        if (currentPoints.size >= 2) {
            val path = androidx.compose.ui.graphics.Path()
            currentPoints.forEachIndexed { index, p ->
                if (index == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            val liveColor = try {
                Color(android.graphics.Color.parseColor(activeColorHex))
            } catch (e: Exception) { Color.Red }
            drawPath(path, color = liveColor, style = Stroke(width = 6f))
        }
    }
}
