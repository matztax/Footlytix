# TaktikApp — Grundgerüst für Amateurfußball-Taktikanalyse

Kotlin/Jetpack-Compose-App, Android-first, mit Firebase-Cloud-Sync und Offline-First-Architektur.

## Setup

1. In Android Studio (Koala oder neuer) als bestehendes Projekt öffnen.
2. Ein Firebase-Projekt anlegen (console.firebase.google.com), Android-App mit
   Package-Name `com.taktikapp` registrieren, `google-services.json` herunterladen
   und nach `app/google-services.json` legen (Datei ist in `.gitignore`, da sie
   projektspezifische Schlüssel enthält — nicht einchecken).
3. In der Firebase Console aktivieren: **Authentication** (mind. E-Mail/Passwort),
   **Firestore**, **Storage**, **Cloud Messaging**.
4. Gradle-Sync ausführen, dann normal bauen/starten.

Es gibt aktuell **keinen Login-Screen** — die App arbeitet mit einer festen
`DEMO_TEAM_ID` (`AppNavigation.kt`), damit alle Module sofort testbar sind.
Das ist der nächste sinnvolle Ausbauschritt (Firebase Auth + Team-/Vereinsauswahl).

## APK über GitHub bauen (ohne lokales Android Studio)

Das Repository enthält einen fertigen GitHub-Actions-Workflow
(`.github/workflows/build-apk.yml`), der bei jedem Push automatisch eine
Debug-APK baut — du brauchst dafür keine Android-SDK-Installation auf dem
eigenen Rechner.

**1. Repository auf GitHub anlegen und Projekt pushen**
```bash
cd taktikapp
git init
git add .
git commit -m "Initial commit: TaktikApp Grundgerüst"
git branch -M main
git remote add origin https://github.com/<dein-username>/<dein-repo>.git
git push -u origin main
```

**2. (Empfohlen) Echtes Firebase-Projekt hinterlegen**
Ohne diesen Schritt baut die APK trotzdem (über die mitgelieferte
`app/google-services.json.sample`), aber Cloud-Sync/Login funktionieren dann
nicht. Für ein funktionsfähiges Firebase-Backend:
- Im GitHub-Repo: **Settings → Secrets and variables → Actions → New repository secret**
- Name: `GOOGLE_SERVICES_JSON`
- Wert: kompletter Inhalt deiner echten `google-services.json` (aus der
  Firebase Console, siehe Schritt 2 oben im Setup-Abschnitt), als reiner Text eingefügt

**3. Build auslösen**
Passiert automatisch bei jedem Push nach `main`. Manuell geht's über den
**Actions**-Tab im Repo → Workflow "Build Debug APK" → **Run workflow**.

**4. APK herunterladen**
Im Actions-Tab auf den abgeschlossenen Workflow-Lauf klicken → unten unter
**Artifacts** liegt `taktikapp-debug-apk` als ZIP zum Download.

**5. Auf dem Handy installieren**
APK aus dem ZIP entpacken, aufs Android-Gerät übertragen, öffnen. Android
fragt beim ersten Mal nach der Erlaubnis "Installation aus unbekannten
Quellen" — das ist bei einer selbst gebauten Debug-APK normal und nötig.

Hinweis: Dies ist eine **Debug-APK**, unsigniert für den Play Store, aber
auf jedem Android-Gerät direkt installierbar — genau richtig zum Testen im
Verein. Eine signierte Release-APK für eine spätere Play-Store-Veröffentlichung
ist ein separater, noch nicht eingerichteter Schritt (eigener Signing-Key,
Release-Build-Variante).

## Was ist enthalten

| Modul | Status |
|---|---|
| Datenmodelle (Player, Team, Formation, SetPiece, VideoAnnotation) | ✅ vollständig, `@Serializable` |
| Room-Offline-Datenbank | ✅ vollständig, inkl. `needsSync`-Flag pro Zeile |
| Firebase-Sync (Firestore/Storage/FCM) | ✅ Grundgerüst inkl. `SyncWorker` (WorkManager, alle 15 Min bei bestehender Verbindung) |
| Kaderverwaltung | ✅ funktionsfähig |
| Formations-Board | ✅ Drag & Drop, Mehrphasen-Szenarien (z.B. Grundordnung vs. Reaktion auf gegnerischen Systemwechsel) |
| Set-Piece-Planer | ✅ Rollenzuteilung (Zielspieler/Blocker/Absteller/Absicherung/Ausführender/Läufer) |
| Video-Telestration | ✅ ExoPlayer + zeitstempel-gebundenes Zeichnen (Linie/Pfeil/Kreis/Rechteck/Freihand/Marker/Zone) |
| Spieler-Briefings (Clip-Zuweisung, Lesestatus) | ⚠️ UI-Grundgerüst vorhanden, Anbindung an echte Daten + Cloud Function für den Push-Versand fehlt noch (`TODO` in `AppNavigation.kt`) |
| Login/Team-Auswahl | ❌ noch nicht gebaut |

## Bewusst NICHT enthalten (und warum)

Diese Punkte aus deiner ursprünglichen Anforderungsliste sind Funktionen aus
professionellen Systemen (Hudl Sportscode, Wyscout, CoachPaint) und für den
Amateurbereich technisch/wirtschaftlich nicht sinnvoll:

- **Automatisches Spieler-Tracking im Video** (mitlaufende Kreise/Linien): erfordert
  Computer-Vision-Objekterkennung, die bei Amateur-Handyvideo (wackelig, ein
  Kamerawinkel, wechselndes Licht) keine verlässlichen Ergebnisse liefert. Stattdessen:
  manuelles, zeitstempel-gebundenes Zeichnen (siehe `DrawingStroke` in `VideoAnnotation.kt`).
- **Opta/Stats-Perform-Datenanbindung**: kostenpflichtige Profi-Lizenzen, für
  Amateurvereine weder verfügbar noch sinnvoll. Event-Tags (Tor, Schuss, Foul etc.)
  werden stattdessen manuell vom Analysten gesetzt (`EventTag`).
- **GPS-/Wearable-Integration, automatische Heatmaps/Passnetzwerke**: erfordert
  spezielle Hardware (Catapult, Polar Team Pro o.ä.), die im Amateurbereich
  praktisch nie vorhanden ist.
- **Multi-Angle-Sync, Sichtfeld-Berechnung pro Millisekunde**: setzt synchronisierte
  Mehrkamerasysteme mit Framegenauer Kalibrierung voraus — Infrastruktur, die auf
  Kreisliganiveau nicht existiert.
- **Smartboard/Beamer-Präsentationsmodus**: technisch später über Chromecast/
  Miracast nachrüstbar, aber kein Kernbestandteil des Grundgerüsts.

## Architekturentscheidungen

- **Local-first**: Jede Aktion schreibt zuerst in Room (`needsSync = true`), die UI
  reagiert sofort. Ein `SyncWorker` synchronisiert im Hintergrund nach Firestore,
  sobald eine Verbindung besteht — deckt den Fall "Kabine ohne WLAN" ab.
- **JSON-Felder statt normalisierter Tabellen** für verschachtelte Daten
  (Formationsphasen, Zeichnungs-Strokes, Set-Piece-Zuweisungen), um die lokale
  Struktur nah an Firestores dokumentenbasiertem Modell zu halten und
  Sync-Konflikte zu minimieren.
- **KMP-Vorbereitung für iOS**: `data/model` und `data/repository` enthalten
  bewusst keine Android-spezifischen Typen (Ausnahme: `android.net.Uri` für
  Datei-/Storage-Zugriffe, die bei einer KMP-Migration hinter ein `expect/actual`
  wandern würden). Damit lässt sich dieser Code später relativ direkt in ein
  KMP-`shared`-Modul verschieben; die UI (Compose) bleibt Android-spezifisch,
  bis ggf. auf Compose Multiplatform umgestellt wird.
- **Kein Dependency-Injection-Framework** (Hilt/Koin) im Grundgerüst, um die
  Einstiegshürde niedrig zu halten (`AppViewModelFactory.kt`). Bei wachsendem
  Funktionsumfang sollte das mittelfristig durch Hilt ersetzt werden.

## Nächste sinnvolle Schritte

1. Firebase Auth + Login-/Team-Auswahl-Screen (ersetzt `DEMO_TEAM_ID`).
2. Video-Auswahl/-Import (Storage Access Framework) vor `VideoAnnotationScreen`.
3. Cloud Function, die bei Zuweisung eines Clips den FCM-Push an die
   `deviceToken`s der ausgewählten Spieler auslöst, plus Lesebestätigungs-Schreiben
   in Firestore.
4. Formation-Board: Speichern/Laden bestehender Formationen aus der Liste
   (aktuell wird bei jedem Öffnen eine neue erzeugt).
5. Unit-Tests für die Repository-Sync-Logik (`needsSync`-Handling).
6. Release-Signing-Konfiguration (eigener Keystore + Secrets im Workflow), falls
   später eine signierte Release-APK oder Play-Store-Veröffentlichung gebraucht wird.
